// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <ck_tile/core/numeric/integer.hpp>
#include <ck_tile/host.hpp>
#include <ck_tile/ops/epilogue.hpp>

#include "multihead_attention_problem.hpp"
#include "multihead_attention_tile_traits.hpp"
#include "multihead_attention_pipeline_big_k0_loop.hpp"
#include "multihead_attention_pipeline_small_k0_loop.hpp"
#include "multihead_attention_pipeline_big_k0_loop_gemv.hpp"
#include "multihead_attention_pipeline_small_k0_loop_gemv.hpp"
#include "multihead_attention_kernel.hpp"

#include "multihead_attention_setting.hpp"
#include "multihead_attention_params.hpp"
#include "bool_switch.hpp"

template <typename InOutDataType,
          typename MaskDataType,
          ck_tile::index_t kM,
          ck_tile::index_t kMaxK,
          ck_tile::index_t MaxKN,
          bool kDoKMask,
          bool kDoQMask>
struct multihead_attention_dispatch
{
    using MultiheadAttentionProblem_ = ck_tile::MultiheadAttentionProblem<
        InOutDataType,
        typename MultiheadAttentionTypeConfig<InOutDataType>::GemmAccDataType,
        typename MultiheadAttentionTypeConfig<InOutDataType>::SMComputeDataType,
        MaskDataType,
        MultiheadAttentionTileShape<kM, kMaxK, MaxKN>>;

    static void Run(const MultiheadAttentionParams& param, hipStream_t stream)
    {
        using MultiheadAttentionTileShape_ = MultiheadAttentionTileShape<kM, kMaxK, MaxKN>;

        const bool pad_aseqlen     = !(param.a_seqlen % MultiheadAttentionTileShape_::kM == 0);
        const bool pad_seqlen      = !(param.seqlen % MultiheadAttentionTileShape_::kN0 == 0);
        const bool pad_ab0_head_sz = !(param.head_sz % MultiheadAttentionTileShape_::kMaxK == 0);
        const bool pad_b1d_head_sz = !(param.b1_head_sz % MultiheadAttentionTileShape_::kN1 == 0);
        const bool merge_abatch    = (param.num_batch == 1);
        constexpr auto lds_size =
            (MultiheadAttentionTileShape_::kK0 * MultiheadAttentionTileShape_::kN0 +
             MultiheadAttentionTileShape_::kK1 * MultiheadAttentionTileShape_::kN1) *
            sizeof(InOutDataType);
        constexpr ck_tile::index_t blocks_per_cu = 65536 / lds_size >= 2 ? 2 : 1;

        BOOL_SWITCH_5(
            pad_aseqlen,
            kPadASeqLen,
            pad_seqlen,
            kPadSeqLen,
            pad_ab0_head_sz,
            kPadAB0HeadSz,
            pad_b1d_head_sz,
            kPadB1DHeadSz,
            merge_abatch,
            kMergeABatch,
            [&] {
                using MultiheadAttentionTraits_ =
                    ck_tile::MultiheadAttentionTileTraits<kPadASeqLen,
                                                          kPadSeqLen,
                                                          kPadAB0HeadSz,
                                                          kPadB1DHeadSz,
                                                          kDoKMask,
                                                          kDoQMask,
                                                          kMergeABatch,
                                                          blocks_per_cu>;

                constexpr ck_tile::index_t k0_loops =
                    MultiheadAttentionTileShape_::kMaxK / MultiheadAttentionTileShape_::kK0;

                if constexpr(k0_loops > 2)
                {
                    if constexpr(kM != 1)
                    {
                        using MultiheadAttentionPipeline =
                            ck_tile::BlockMultiheadAttentionPipelineBigK0Loop<
                                MultiheadAttentionProblem_,
                                MultiheadAttentionTraits_>;

                        using MultiheadAttentionEpilogue = ck_tile::Default2DEpilogue<
                            ck_tile::Default2DEpilogueProblem<typename MultiheadAttentionTypeConfig<
                                                                  InOutDataType>::GemmAccDataType,
                                                              InOutDataType,
                                                              false,
                                                              kPadB1DHeadSz>>;

                        using MultiheadAttentionKernel =
                            ck_tile::MultiheadAttentionKernel<MultiheadAttentionPipeline,
                                                              MultiheadAttentionEpilogue>;

                        RunKernel<MultiheadAttentionKernel>(param, stream);
                    }
                    else
                    {
                        using MultiheadAttentionPipeline =
                            ck_tile::BlockMultiheadAttentionPipelineBigK0Loop_gemv<
                                MultiheadAttentionProblem_,
                                MultiheadAttentionTraits_>;

                        using MultiheadAttentionEpilogue = ck_tile::Default2DEpilogue<
                            ck_tile::Default2DEpilogueProblem<typename MultiheadAttentionTypeConfig<
                                                                  InOutDataType>::GemmAccDataType,
                                                              InOutDataType,
                                                              false,
                                                              kPadB1DHeadSz>>;

                        using MultiheadAttentionKernel =
                            ck_tile::MultiheadAttentionKernel<MultiheadAttentionPipeline,
                                                              MultiheadAttentionEpilogue>;

                        RunKernel<MultiheadAttentionKernel>(param, stream);
                    }
                }
                else
                {
                    if constexpr(kM != 1)
                    {
                        using MultiheadAttentionPipeline =
                            ck_tile::BlockMultiheadAttentionPipelineSmallK0Loop<
                                MultiheadAttentionProblem_,
                                MultiheadAttentionTraits_>;

                        using MultiheadAttentionEpilogue = ck_tile::Default2DEpilogue<
                            ck_tile::Default2DEpilogueProblem<typename MultiheadAttentionTypeConfig<
                                                                  InOutDataType>::GemmAccDataType,
                                                              InOutDataType,
                                                              false,
                                                              kPadB1DHeadSz>>;

                        using MultiheadAttentionKernel =
                            ck_tile::MultiheadAttentionKernel<MultiheadAttentionPipeline,
                                                              MultiheadAttentionEpilogue>;

                        RunKernel<MultiheadAttentionKernel>(param, stream);
                    }
                    else
                    {
                        using MultiheadAttentionPipeline =
                            ck_tile::BlockMultiheadAttentionPipelineSmallK0Loop_gemv<
                                MultiheadAttentionProblem_,
                                MultiheadAttentionTraits_>;

                        using MultiheadAttentionEpilogue = ck_tile::Default2DEpilogue<
                            ck_tile::Default2DEpilogueProblem<typename MultiheadAttentionTypeConfig<
                                                                  InOutDataType>::GemmAccDataType,
                                                              InOutDataType,
                                                              false,
                                                              kPadB1DHeadSz>>;

                        using MultiheadAttentionKernel =
                            ck_tile::MultiheadAttentionKernel<MultiheadAttentionPipeline,
                                                              MultiheadAttentionEpilogue>;

                        RunKernel<MultiheadAttentionKernel>(param, stream);
                    }
                }
            });
    };

    template <typename MultiheadAttentionKernel>
    static void RunKernel(const MultiheadAttentionParams& param, hipStream_t stream)
    {
        const auto kargs = [&] {
            return MultiheadAttentionKernel::MakeKargs(param.a_ptr,
                                                       param.b0_ptr,
                                                       param.mask_ptr,
                                                       param.qmask_ptr,
                                                       param.indices_ptr,
                                                       param.b1_ptr,
                                                       param.d_ptr,
                                                       param.num_index,
                                                       param.num_batch,
                                                       param.seqlen,
                                                       param.a_seqlen,
                                                       param.num_head,
                                                       param.head_sz,
                                                       param.b1_head_sz,
                                                       param.a_batch_stride,
                                                       param.a_seq_stride,
                                                       param.a_nhead_stride,
                                                       param.b0_batch_stride,
                                                       param.b0_seq_stride,
                                                       param.b0_nhead_stride,
                                                       param.mask_batch_stride,
                                                       param.qmask_batch_stride,
                                                       param.b1_batch_stride,
                                                       param.b1_seq_stride,
                                                       param.b1_nhead_stride,
                                                       param.d_batch_stride,
                                                       param.d_seq_stride,
                                                       param.d_nhead_stride);
        }();

        dim3 kGridSize                         = MultiheadAttentionKernel::GridSize(&kargs);
        constexpr dim3 kBlockSize              = MultiheadAttentionKernel::BlockSize();
        constexpr ck_tile::index_t kBlockPerCu = MultiheadAttentionKernel::kBlockPerCu;

        (void)ck_tile::launch_kernel(
            ck_tile::stream_config{stream, false},
            ck_tile::make_kernel<kBlockSize.x, kBlockPerCu>(
                MultiheadAttentionKernel{}, kGridSize, kBlockSize, 0, kargs));
    };
};

template <typename InOutDataType,
          typename MaskDataType,
          ck_tile::index_t kM,
          ck_tile::index_t kMaxK,
          ck_tile::index_t MaxKN,
          bool kDoKMask,
          bool kDoQMask>
void run_multihead_attention(const MultiheadAttentionParams& param, hipStream_t stream)
{
    multihead_attention_dispatch<InOutDataType,
                                 MaskDataType,
                                 kM,
                                 kMaxK,
                                 MaxKN,
                                 kDoKMask,
                                 kDoQMask>::Run(param, stream);
};

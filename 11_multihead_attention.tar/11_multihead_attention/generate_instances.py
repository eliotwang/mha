# noqa: C801
# Copyright (c) 2023-2024, Advanced Micro Devices, Inc. All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.
#

import os
from pathlib import Path

INSTANCE_HEADER = """
// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.
"""

INSTANCE_TEMPLATE = """
#include <ck_tile/core.hpp>

#include "multihead_attention_dispatch.hpp"

// clang-format off
template void run_multihead_attention<{dtype}, {mask_dtype}, {tilem}, {b0headsz_max}, {b1headsz_max}, {kmask}, {qmask}>(const MultiheadAttentionParams& param, hipStream_t stream);
// clang-format on
"""

INSTANCE_FNAME = "multihead_attention_{dtype}_{mask_dtype}_tilem{tilem}_b0headsz{b0headsz_max}_b1headsz{b1headsz_max}_kmask{kmask}_qmask{qmask}.cpp"

TYPE_CTYPE_MAP = {
    "fp16" : "ck_tile::fp16_t",
}

def create_instances(instance_dir: Path) -> None:
    for dtype in ["fp16"]:
        for mask_dtype in ["uint8_t"]:
            for b0headsz_max in [16, 32, 64, 128, 256]:
                for b1headsz_max in [16, 32, 64, 128, 256]:
                    for tilem in [1,16,32,48,64,128,256]:
                        for kmask in [True, False]:
                            for qmask in [True, False]:
                                kmask_str = 'true' if kmask else 'false'
                                qmask_str = 'true' if qmask else 'false'
                                
                                fname = INSTANCE_FNAME.format(
                                    dtype=dtype,
                                    mask_dtype=mask_dtype,
                                    tilem=tilem,
                                    b0headsz_max=b0headsz_max,
                                    b1headsz_max=b1headsz_max,
                                    kmask=kmask,
                                    qmask=qmask,
                                )
                                instance = INSTANCE_TEMPLATE.format(
                                    dtype=TYPE_CTYPE_MAP[dtype],
                                    mask_dtype=mask_dtype,
                                    tilem=tilem,
                                    b0headsz_max=b0headsz_max,
                                    b1headsz_max=b1headsz_max,
                                    kmask=kmask_str,
                                    qmask=qmask_str,
                                )
                                (instance_dir / fname).write_text(INSTANCE_HEADER + instance)

if __name__ == "__main__":
    this_dir = os.path.dirname(__file__)
    output_dir = Path(this_dir) / "instances"
    output_dir.mkdir(parents=True, exist_ok=True)

    # remove existing files in the directory
    files = os.listdir(output_dir)
    for ff in files:
        file_path = os.path.join(output_dir, ff)
        os.remove(file_path)

    create_instances(output_dir)
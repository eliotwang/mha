
// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#include <ck_tile/core.hpp>

#include "multihead_attention_dispatch.hpp"

// clang-format off
template void run_multihead_attention<ck_tile::fp16_t, uint8_t, 256, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
// clang-format on

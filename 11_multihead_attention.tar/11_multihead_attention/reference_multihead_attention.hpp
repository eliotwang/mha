// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <thread>
#include <cassert>
#include <iostream>
#include "ck_tile/core.hpp"
#include "ck_tile/host/host_tensor.hpp"

namespace ck_tile {

// clang-format off
// Reference implementation of MultiheadAttention problem, which does the following from input tensors:
// S[num_batch, num_head, seqlen] = A[num_batch, num_head, head_sz] @ BO[num_batch, seqlen, num_head, head_sz]
// P[num_head, num_batch, seqlen] = RowSoftmax(S[num_batch, num_head, seqlen] with filtering by mask before softmax-ing
// D[num_batch, num_head, head_sz] = P[num_head, num_batch, seqlen] @ B1T[num_batch, seqlen, num_head, head_sz]
// The process is very similar to the decoder attention with one Query token in each batch. But one specical point of 
// MultiheadAttention is that accessed batches of B0/B1/mask tensors are provided by an indices vector.
// clang-format on

template <typename InOutDataType,
          typename MaskDataType,
          typename GemmAccDataType,
          typename SMComputeDataType>
struct reference_multihead_attention
{
    static constexpr void Run(const HostTensor<InOutDataType>& a_batch_nhead_headsz,
                              const HostTensor<InOutDataType>& b0_batch_seq_nhead_headsz,
                              const HostTensor<MaskDataType>& mask_batch_seq,
                              const HostTensor<MaskDataType>& qmask_batch_seq,
                              const std::vector<int>& batch_indices,
                              const HostTensor<InOutDataType>& b1_batch_seq_nhead_headsz,
                              HostTensor<InOutDataType>& d_batch_nhead_headsz,
                              int head_sz,
                              int b1_head_sz,
                              int seqlen,
                              int a_seqlen,
                              int num_batch,
                              int num_index,
                              int num_head,
                              int input_layout,
                              bool do_kmask,
                              bool do_qmask,
                              bool do_gather)
    {
        (void)num_batch;

        if(input_layout == 0)
        {
            assert(a_batch_nhead_headsz.mDes.get_lengths()[2] == num_batch);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[2] == num_batch);
            assert(mask_batch_seq.mDes.get_lengths()[0] == num_batch);
            assert(batch_indices.size() == num_index);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[2] == num_batch);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[0] == num_batch);

            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[1] == seqlen);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[1] == seqlen);
            assert(mask_batch_seq..mDes.get_lengths()[1] == seqlen);

            assert(a_batch_nhead_headsz.mDes.get_lengths()[0] == num_head);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[0] == num_head);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[0] == num_head);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[2] == num_head);

            assert(a_batch_nhead_headsz.mDes.get_lengths()[3] == head_sz);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[3] == head_sz);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[3] == b1_head_sz);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[3] == b1_head_sz);

            const GemmAccDataType mul = ck_tile::type_convert<GemmAccDataType>(1.0f) /
                                        std::sqrt(ck_tile::type_convert<GemmAccDataType>(head_sz));

            auto f = [&](auto i_batch, auto i_seq, auto i_head) {
                int i_batchs = 0, i_batch_phys = 0;
                if(do_gather)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = batch_indices[i_batch];
                }
                else if(num_batch == 1)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = 0;
                }
                else if(num_index == num_batch)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = i_batch;
                }
                else if(num_index == 1)
                {
                    i_batch_phys = i_batch;
                    i_batchs     = 0;
                }
                else
                {
                    std::cerr << "Unsupported batch setting!" << std::endl;
                    assert(0);
                }

                std::vector<SMComputeDataType> softmax_res; // store seqlen values

                SMComputeDataType v_exp_sum = 0.f;
                SMComputeDataType v_max     = -numeric<SMComputeDataType>::infinity();

                std::vector<SMComputeDataType> locals; // store seqlen values

                // first Gemm and masking

                for(int s = 0; s < seqlen; s++)
                {
                    GemmAccDataType dot_prod = 0.f;
                    for(int k = 0; k < head_sz; k++)
                    {
                        InOutDataType areg = a_batch_nhead_headsz(i_head, i_batchs, i_seq, k);
                        InOutDataType breg = b0_batch_seq_nhead_headsz(i_head, i_batch_phys, s, k);

                        dot_prod += ck_tile::type_convert<GemmAccDataType>(areg) *
                                    ck_tile::type_convert<GemmAccDataType>(breg);
                    }

                    dot_prod = dot_prod * mul;

                    SMComputeDataType res =
                        do_kmask ? mask_batch_seq(i_batch_phys, s)
                                       ? ck_tile::type_convert<SMComputeDataType>(dot_prod)
                                       : -numeric<SMComputeDataType>::infinity()
                                 : ck_tile::type_convert<SMComputeDataType>(dot_prod);

                    locals.push_back(res);
                };

                // get max
                for(auto val : locals)
                    v_max = (val > v_max) ? val : v_max;

                // get sum-of-exp (with stabilization)
                if(v_max != -numeric<SMComputeDataType>::infinity())
                {
                    for(auto val : locals)
                    {
                        v_exp_sum += ck_tile::exp(val - v_max);
                    }
                }

                // normalize using max and sum-of-exp
                for(int s = 0; s < seqlen; s++)
                {
                    SMComputeDataType normalized_val;

                    if(v_exp_sum == ck_tile::type_convert<SMComputeDataType>(0.0f))
                        normalized_val = ck_tile::type_convert<SMComputeDataType>(
                            1.0f / static_cast<float>(seqlen));
                    else
                        normalized_val = ck_tile::exp(locals[s] - v_max) / v_exp_sum;

                    SMComputeDataType res_qmask =
                        do_qmask ? qmask_batch_seq(i_batchs, i_seq)
                                       ? normalized_val
                                       : ck_tile::type_convert<SMComputeDataType>(0.0f)
                                 : normalized_val;

                    softmax_res.push_back(res_qmask);
                }

                // second Gemm
                for(int k = 0; k < b1_head_sz; k++)
                {
                    GemmAccDataType dot_prod = 0.f;

                    for(int s = 0; s < seqlen; s++)
                    {
                        InOutDataType areg = ck_tile::type_convert<InOutDataType>(softmax_res[s]);
                        InOutDataType breg = b1_batch_seq_nhead_headsz(i_head, i_batch_phys, s, k);

                        dot_prod += ck_tile::type_convert<GemmAccDataType>(areg) *
                                    ck_tile::type_convert<GemmAccDataType>(breg);
                    };

                    d_batch_nhead_headsz(i_batch, i_seq, i_head, k) =
                        ck_tile::type_convert<InOutDataType>(dot_prod);
                };
            };

            int max_nindex = (num_index >= num_batch) ? num_index : num_batch;

            make_ParallelTensorFunctor(f, max_nindex, a_seqlen, num_head)(
                std::thread::hardware_concurrency());
        }
        else
        {
            assert(a_batch_nhead_headsz.mDes.get_lengths()[0] == num_batch);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[0] == num_batch);
            assert(mask_batch_seq.mDes.get_lengths()[0] == num_batch);
            assert(batch_indices.size() == num_index);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[0] == num_batch);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[0] == num_batch);

            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[1] == seqlen);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[1] == seqlen);
            assert(mask_batch_seq..mDes.get_lengths()[1] == seqlen);

            assert(a_batch_nhead_headsz.mDes.get_lengths()[2] == num_head);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[2] == num_head);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[2] == num_head);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[2] == num_head);

            assert(a_batch_nhead_headsz.mDes.get_lengths()[3] == head_sz);
            assert(b0_batch_seq_nhead_headsz.mDes.get_lengths()[3] == head_sz);
            assert(b1_batch_seq_nhead_headsz.mDes.get_lengths()[3] == b1_head_sz);
            assert(d_batch_nhead_headsz.mDes.get_lengths()[3] == b1_head_sz);

            const GemmAccDataType mul = ck_tile::type_convert<GemmAccDataType>(1.0f) /
                                        std::sqrt(ck_tile::type_convert<GemmAccDataType>(head_sz));

            auto f = [&](auto i_batch, auto i_seq, auto i_head) {
                int i_batchs = 0, i_batch_phys = 0;
                if(do_gather)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = batch_indices[i_batch];
                }
                else if(num_batch == 1)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = 0;
                }
                else if(num_index == num_batch)
                {
                    i_batchs     = i_batch;
                    i_batch_phys = i_batch;
                }
                else if(num_index == 1)
                {
                    i_batch_phys = i_batch;
                    i_batchs     = 0;
                }
                else
                {
                    std::cerr << "Unsupported batch setting!" << std::endl;
                    assert(0);
                }
                std::vector<SMComputeDataType> softmax_res; // store seqlen values

                SMComputeDataType v_exp_sum = 0.f;
                SMComputeDataType v_max     = -numeric<SMComputeDataType>::infinity();

                std::vector<SMComputeDataType> locals; // store seqlen values

                // first Gemm and masking

                for(int s = 0; s < seqlen; s++)
                {
                    GemmAccDataType dot_prod = 0.f;
                    for(int k = 0; k < head_sz; k++)
                    {
                        InOutDataType areg = a_batch_nhead_headsz(i_batchs, i_seq, i_head, k);
                        InOutDataType breg = b0_batch_seq_nhead_headsz(i_batch_phys, s, i_head, k);

                        dot_prod += ck_tile::type_convert<GemmAccDataType>(areg) *
                                    ck_tile::type_convert<GemmAccDataType>(breg);
                    }

                    dot_prod = dot_prod * mul;

                    SMComputeDataType res =
                        do_kmask ? mask_batch_seq(i_batch_phys, s)
                                       ? ck_tile::type_convert<SMComputeDataType>(dot_prod)
                                       : -numeric<SMComputeDataType>::infinity()
                                 : ck_tile::type_convert<SMComputeDataType>(dot_prod);

                    locals.push_back(res);
                };

                // get max
                for(auto val : locals)
                    v_max = (val > v_max) ? val : v_max;

                // get sum-of-exp (with stabilization)
                if(v_max != -numeric<SMComputeDataType>::infinity())
                {
                    for(auto val : locals)
                    {
                        v_exp_sum += ck_tile::exp(val - v_max);
                    }
                }

                // normalize using max and sum-of-exp
                for(int s = 0; s < seqlen; s++)
                {
                    SMComputeDataType normalized_val;

                    if(v_exp_sum == ck_tile::type_convert<SMComputeDataType>(0.0f))
                        normalized_val = ck_tile::type_convert<SMComputeDataType>(
                            1.0f / static_cast<float>(seqlen));
                    else
                        normalized_val = ck_tile::exp(locals[s] - v_max) / v_exp_sum;

                    SMComputeDataType res_qmask =
                        do_qmask ? qmask_batch_seq(i_batchs, i_seq)
                                       ? normalized_val
                                       : ck_tile::type_convert<SMComputeDataType>(0.0f)
                                 : normalized_val;

                    softmax_res.push_back(res_qmask);
                }

                // second Gemm
                for(int k = 0; k < b1_head_sz; k++)
                {
                    GemmAccDataType dot_prod = 0.f;

                    for(int s = 0; s < seqlen; s++)
                    {
                        InOutDataType areg = ck_tile::type_convert<InOutDataType>(softmax_res[s]);
                        InOutDataType breg = b1_batch_seq_nhead_headsz(i_batch_phys, s, i_head, k);

                        dot_prod += ck_tile::type_convert<GemmAccDataType>(areg) *
                                    ck_tile::type_convert<GemmAccDataType>(breg);
                    };

                    d_batch_nhead_headsz(i_batch, i_seq, i_head, k) =
                        ck_tile::type_convert<InOutDataType>(dot_prod);
                };
            };

            int max_nindex = (num_index >= num_batch) ? num_index : num_batch;

            make_ParallelTensorFunctor(f, max_nindex, a_seqlen, num_head)(
                std::thread::hardware_concurrency());
        }
    }
};

} // namespace ck_tile

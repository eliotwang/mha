#!/ bin / bash
BUILD=/code/composable_kernel-internal/build
EXE=$BUILD/bin/tile_example_multihead_attention

while read -r line; do
    eval "$line"
    
    if [ "$HeadSplited" = "true" ]; then
        input_layout=0
    else
        input_layout=1
    fi

    cmd="$EXE -v=1 -prec=fp16 -nidx=$Bq -b=$Bkv -a_seq=$Tq -seq=$Tkv -nhead=$HeadNum -hsize=$qkHeadSz -b1_hsize=$vHeadSz -init=u -seed=123 -perf=1 -maskmax=$maskmax -qmaskmax=$qmaskmax  -input_layout=$input_layout -do_gather=$do_gather"
    echo "$cmd"

    # 执行命令
    eval "$cmd"
done <<EOF
Bq=150 Bkv=150 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=128 vHeadSz=256  maskmax=-1 qmaskmax=-1 do_gather=0 HeadSplited=true 
Bq=2 Bkv=2 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=128 vHeadSz=256 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=false 
Bq=20 Bkv=20 Tq=48 Tkv=48 HeadNum=4 qkHeadSz=128 vHeadSz=128 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=false 
Bq=20 Bkv=20 Tq=48 Tkv=48 HeadNum=4 qkHeadSz=128 vHeadSz=128 maskmax=0 qmaskmax=0 do_gather=0 HeadSplited=false 
Bq=15 Bkv=15 Tq=14 Tkv=14 HeadNum=8 qkHeadSz=1024 vHeadSz=2048 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=true 
Bq=15 Bkv=15 Tq=14 Tkv=14 HeadNum=8 qkHeadSz=128 vHeadSz=256 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=true
Bq=15 Bkv=15 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=352 vHeadSz=352 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=true
Bq=15 Bkv=15 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=352 vHeadSz=352 maskmax=0 qmaskmax=0 do_gather=0 HeadSplited=true
Bq=15 Bkv=15 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=44 vHeadSz=44 maskmax=-1 qmaskmax=0 do_gather=0 HeadSplited=true
Bq=15 Bkv=15 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=44 vHeadSz=44 maskmax=0 qmaskmax=0 do_gather=0 HeadSplited=true
Bq=2 Bkv=2 Tq=4 Tkv=8 HeadNum=4 qkHeadSz=64 vHeadSz=64 maskmax=1 qmaskmax=5 do_gather=0 HeadSplited=false 
Bq=2 Bkv=2 Tq=4 Tkv=8 HeadNum=4 qkHeadSz=64 vHeadSz=64 maskmax=5 qmaskmax=5 do_gather=0 HeadSplited=false
EOF

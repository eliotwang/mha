// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include "ck_tile/core.hpp"
#include "ck_tile/ops/common/tensor_layout.hpp"
#include "ck_tile/ops/gemm/pipeline/tile_gemm_shape.hpp"
#include "ck_tile/ops/gemm/warp/warp_gemm.hpp"
#include "ck_tile/ops/gemm/pipeline/block_gemm_pipeline_problem.hpp"
#include "ck_tile/ops/gemm/block/block_gemm_areg_bsmem_creg_v1_custom_policy.hpp"
#include "ck_tile/ops/gemm/block/block_gemm_areg_bsmem_creg_v1.hpp"
#include "ck_tile/ops/gemm/block/block_gemm_areg_bsmem_creg_one_warp_v1.hpp"

namespace ck_tile {

struct MultiheadAttentionPolicy
{
    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetSmemSizeB0()
    {
        return MakeB0LdsBlockDescriptor<Problem>().get_element_space_size() *
               sizeof(typename Problem::InOutDataType);
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetSmemSizeB1()
    {
        return MakeB1TLdsBlockDescriptor<Problem>().get_element_space_size() *
               sizeof(typename Problem::InOutDataType);
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentA()
    {
        using BlockGemm = remove_cvref_t<decltype(GetAB0BlockGemm<Problem>())>;

        constexpr auto config = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG              = remove_cvref_t<decltype(config.template at<0>())>;

        using ADataType = remove_cvref_t<typename Problem::InOutDataType>;

        return min(WG::kK / WG::WarpGemmAttribute::Impl::kABKLane,
                   static_cast<index_t>(16 / sizeof(ADataType)));
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentB0()
    {
        using B0DataType = remove_cvref_t<typename Problem::InOutDataType>;

        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN0;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK0;

        // remember that B0 is accessed by each warp separately
        return min((kNPerBlock * kKPerBlock) / Problem::kBlockSize,
                   static_cast<index_t>(16 / sizeof(B0DataType)));
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentMask()
    {
        using BlockGemm       = remove_cvref_t<decltype(GetAB0BlockGemm<Problem>())>;
        constexpr auto config = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG              = remove_cvref_t<decltype(config.template at<0>())>;

        // remember that C warp-tile is transposed by AB0 BlockGemm
        constexpr auto vec_size = WG::WarpGemmAttribute::Impl::kCM1PerLane;

        return vec_size;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentQMask()
    {
        constexpr auto vec_size = 1;
        return vec_size;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentB1()
    {
        using B1DataType = remove_cvref_t<typename Problem::InOutDataType>;

        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN1;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK1;

        return min((kNPerBlock * kKPerBlock) / Problem::kBlockSize,
                   static_cast<index_t>(16 / sizeof(B1DataType)));
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr index_t GetAlignmentD()
    {
        using BlockGemm       = remove_cvref_t<decltype(GetPB1TBlockGemm<Problem>())>;
        constexpr auto config = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG              = remove_cvref_t<decltype(config.template at<0>())>;

        // remember that C warp-tile is transposed by PB1T BlockGemm
        constexpr auto vec_size = WG::WarpGemmAttribute::Impl::kCM1PerLane;

        return vec_size;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeADramTileDistribution()
    {
        using BlockGemm = remove_cvref_t<decltype(GetAB0BlockGemm<Problem>())>;

        constexpr auto config   = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG                = remove_cvref_t<decltype(config.template at<0>())>;
        constexpr index_t MWarp = config.template at<1>();
        constexpr index_t NWarp = config.template at<2>();

        static_assert(NWarp == 1, "NWarp == 1 is required since dim-N of Gemm0 is dim-K of Gemm1");

        // Gemm0 is restricted to have single warp allocate on dim-N, but Gemm1 is not
        // restricted
        constexpr index_t Gemm1NWarp = Problem::MultiheadAttentionTileShape::NumWarpsGemm1 /
                                       Problem::MultiheadAttentionTileShape::NumWarpsGemm0;

        constexpr index_t kMPerBlock = Problem::MultiheadAttentionTileShape::kM;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK0;
        constexpr index_t kMaxK      = Problem::MultiheadAttentionTileShape::kMaxK;

        // K2 is equal to Impl::kABKPerLane * kKIterPerWarpGemm
        constexpr index_t K3 = WG::kK / WG::WarpGemmAttribute::Impl::kABKLane;
        constexpr index_t K2 = WG::WarpGemmAttribute::Impl::kABKLane;
        constexpr index_t K1 = kKPerBlock / (K2 * K3);
        constexpr index_t K0 = kMaxK / kKPerBlock;
        constexpr index_t M2 = WG::WarpGemmAttribute::Impl::kAMLane;
        constexpr index_t M1 = MWarp;
        constexpr index_t M0 = kMPerBlock / (M2 * M1);

        constexpr auto a_block_dstr_encoding =
            tile_distribution_encoding<sequence<Gemm1NWarp>,
                                       tuple<sequence<M0, M1, M2>, sequence<K0, K1, K2, K3>>,
                                       tuple<sequence<1, 0>, sequence<2, 1>>,
                                       tuple<sequence<1, 0>, sequence<2, 2>>,
                                       sequence<1, 2, 2, 2>,
                                       sequence<0, 0, 1, 3>>{};

        constexpr auto a_block_dstr = make_static_tile_distribution(a_block_dstr_encoding);

        return a_block_dstr;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeB0DramTileDistribution()
    {
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN0;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK0;

        constexpr index_t K1 = GetAlignmentB0<Problem>();
        constexpr index_t K0 = kKPerBlock / K1;

        constexpr index_t N1 = get_warp_size() / K0;
        constexpr index_t N0 = Problem::kBlockSize / get_warp_size();
        constexpr index_t N2 = kNPerBlock / (N0 * N1);

        return make_static_tile_distribution(
            tile_distribution_encoding<sequence<0>,
                                       tuple<sequence<N0, N1, N2>, sequence<K0, K1>>,
                                       tuple<sequence<1>, sequence<1, 2>>,
                                       tuple<sequence<0>, sequence<1, 0>>,
                                       sequence<1, 2>,
                                       sequence<2, 1>>{});
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeB0LdsBlockDescriptor()
    {
        using B0DataType = remove_cvref_t<typename Problem::InOutDataType>;

        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN0;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK0;
        constexpr index_t kKPack     = 8 / sizeof(B0DataType);

        constexpr auto b0_lds_block_desc_0 = make_naive_tensor_descriptor(
            make_tuple(number<kKPerBlock / kKPack>{}, number<kNPerBlock>{}, number<kKPack>{}),
            make_tuple(number<(kNPerBlock + 1) * kKPack>{}, number<kKPack>{}, number<1>{}),
            number<4>{},
            number<1>{});

        constexpr auto b0_lds_block_desc = transform_tensor_descriptor(
            b0_lds_block_desc_0,
            make_tuple(
                make_pass_through_transform(number<kNPerBlock>{}),
                make_merge_transform(make_tuple(number<kKPerBlock / kKPack>{}, number<kKPack>{}))),
            make_tuple(sequence<1>{}, sequence<0, 2>{}),
            make_tuple(sequence<0>{}, sequence<1>{}));

        return b0_lds_block_desc;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeQMaskDramTileDistribution()
    {
        using BlockGemm = remove_cvref_t<decltype(GetAB0BlockGemm<Problem>())>;

        constexpr auto config   = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG                = remove_cvref_t<decltype(config.template at<0>())>;
        constexpr index_t MWarp = config.template at<1>();
        constexpr index_t NWarp = config.template at<2>();

        static_assert(NWarp == 1, "NWarp == 1 is required since dim-N of Gemm0 is dim-K of Gemm1");

        // Gemm0 is restricted to have single warp allocate on dim-N, but Gemm1 is not
        // restricted
        constexpr index_t Gemm1NWarp = Problem::MultiheadAttentionTileShape::NumWarpsGemm1 /
                                       Problem::MultiheadAttentionTileShape::NumWarpsGemm0;

        constexpr index_t kMPerBlock = Problem::MultiheadAttentionTileShape::kM;
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN0;

        constexpr index_t M3 = 1;
        constexpr index_t M2 = WG::WarpGemmAttribute::Impl::kCNLane;
        constexpr index_t M1 = MWarp;
        constexpr index_t M0 = kMPerBlock / (M1 * M2);

        constexpr index_t N4 = WG::WarpGemmAttribute::Impl::kCM1PerLane;
        constexpr index_t N3 = WG::WarpGemmAttribute::Impl::kCMLane;
        constexpr index_t N2 = WG::WarpGemmAttribute::Impl::kCM0PerLane;
        constexpr index_t N1 = NWarp;
        constexpr index_t N0 = kNPerBlock / (N1 * N2 * N3 * N4);

        static_assert(M2 == N2 * N3 * N4,
                      "TransposedC WarpGemmAttribute requirements not satisfied!");

        // remember that C warp-tile is transposed by A0B0T BlockGemm
        constexpr auto mask_warp_dstr_encoding = tile_distribution_encoding<sequence<N2, N3, N4>,
                                                                            tuple<sequence<M2, M3>>,
                                                                            tuple<sequence<0, 1>>,
                                                                            tuple<sequence<1, 0>>,
                                                                            sequence<1>,
                                                                            sequence<1>>{};

        constexpr auto mask_block_outer_dstr_encoding =
            tile_distribution_encoding<sequence<N0, N1, Gemm1NWarp>,
                                       tuple<sequence<M0, M1>>,
                                       tuple<sequence<1, 0, 0>>,
                                       tuple<sequence<1, 2, 1>>,
                                       sequence<1>,
                                       sequence<0>>{};

        constexpr auto mask_block_dstr_encoding = detail::make_embed_tile_distribution_encoding(
            mask_block_outer_dstr_encoding, mask_warp_dstr_encoding);

        constexpr auto mask_block_dstr = make_static_tile_distribution(mask_block_dstr_encoding);

        return mask_block_dstr;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeMaskDramTileDistribution()
    {
        using BlockGemm = remove_cvref_t<decltype(GetAB0BlockGemm<Problem>())>;

        constexpr auto config   = BlockGemm::Policy::template GetWarpGemmMWarpNWarp<Problem>();
        using WG                = remove_cvref_t<decltype(config.template at<0>())>;
        constexpr index_t MWarp = config.template at<1>();
        constexpr index_t NWarp = config.template at<2>();

        static_assert(NWarp == 1, "NWarp == 1 is required since dim-N of Gemm0 is dim-K of Gemm1");

        // Gemm0 is restricted to have single warp allocate on dim-N, but Gemm1 is not
        // restricted
        constexpr index_t Gemm1NWarp = Problem::MultiheadAttentionTileShape::NumWarpsGemm1 /
                                       Problem::MultiheadAttentionTileShape::NumWarpsGemm0;

        constexpr index_t kMPerBlock = Problem::MultiheadAttentionTileShape::kM;
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN0;

        constexpr index_t N2 = WG::WarpGemmAttribute::Impl::kCNLane;
        constexpr index_t N1 = NWarp;
        constexpr index_t N0 = kNPerBlock / (N1 * N2);

        constexpr index_t M4 = WG::WarpGemmAttribute::Impl::kCM1PerLane;
        constexpr index_t M3 = WG::WarpGemmAttribute::Impl::kCMLane;
        constexpr index_t M2 = WG::WarpGemmAttribute::Impl::kCM0PerLane;
        constexpr index_t M1 = MWarp;
        constexpr index_t M0 = kMPerBlock / (M1 * M2 * M3 * M4);

        static_assert(N2 == M2 * M3 * M4,
                      "TransposedC WarpGemmAttribute requirements not satisfied!");

        // remember that C warp-tile is transposed by A0B0T BlockGemm
        constexpr auto mask_warp_dstr_encoding =
            tile_distribution_encoding<sequence<N2>,
                                       tuple<sequence<M2, M3, M4>>,
                                       tuple<sequence<1, 0>>,
                                       tuple<sequence<1, 0>>,
                                       sequence<1, 1>,
                                       sequence<0, 2>>{};

        constexpr auto mask_block_outer_dstr_encoding =
            tile_distribution_encoding<sequence<M0, M1, Gemm1NWarp>,
                                       tuple<sequence<N0, N1>>,
                                       tuple<sequence<0, 0, 1>>,
                                       tuple<sequence<1, 2, 1>>,
                                       sequence<1>,
                                       sequence<0>>{};

        constexpr auto mask_block_dstr_encoding = detail::make_embed_tile_distribution_encoding(
            mask_block_outer_dstr_encoding, mask_warp_dstr_encoding);

        constexpr auto mask_block_dstr = make_static_tile_distribution(mask_block_dstr_encoding);

        return mask_block_dstr;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto GetAB0BlockGemm()
    {
        if constexpr(Problem::MultiheadAttentionTileShape::kM > 16)
        {
            using BlockGemmProblem =
                BlockGemmPipelineProblem<typename Problem::InOutDataType,
                                         typename Problem::InOutDataType,
                                         typename Problem::GemmAccDataType,
                                         Problem::kBlockSize,
                                         TileGemmShape<Problem::MultiheadAttentionTileShape::kM,
                                                       Problem::MultiheadAttentionTileShape::kN0,
                                                       Problem::MultiheadAttentionTileShape::kK0>>;

            constexpr auto warp_gemm = []() {
                if constexpr(std::is_same_v<typename Problem::InOutDataType, fp16_t> &&
                             std::is_same_v<typename Problem::GemmAccDataType, float>)
                {
                    return WarpGemmMfmaF16F16F32M16N16K16TransposedCDistribution{};
                }
                else if constexpr(std::is_same_v<typename Problem::InOutDataType, bf16_t> &&
                                  std::is_same_v<typename Problem::GemmAccDataType, float>)
                {
                    return WarpGemmMfmaBf16Bf16F32M16N16K16TransposedCDistribution{};
                }
            }();

            // clang-format off
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<0>{}) == decltype(warp_gemm)::kM, "Check failed!");
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<1>{}) == decltype(warp_gemm)::kN, "Check failed!");
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<2>{}) == decltype(warp_gemm)::kK, "Check failed!");
            // clang-format on 

            using BlockGemmPolicy = BlockGemmARegBSmemCRegV1CustomPolicy<
                typename Problem::InOutDataType,
                typename Problem::InOutDataType,
                typename Problem::GemmAccDataType,
                typename Problem::MultiheadAttentionTileShape::Gemm0BlockWarps,
                decltype(warp_gemm)>;

            return BlockGemmARegBSmemCRegV1<BlockGemmProblem, BlockGemmPolicy>{};
        }
        else
        {
            using BlockGemmProblem =
                BlockGemmPipelineProblem<typename Problem::InOutDataType,
                                         typename Problem::InOutDataType,
                                         typename Problem::GemmAccDataType,
                                         get_warp_size(),
                                         TileGemmShape<Problem::MultiheadAttentionTileShape::kM,
                                                       Problem::MultiheadAttentionTileShape::kN0,
                                                       Problem::MultiheadAttentionTileShape::kK0>>;

            constexpr auto warp_gemm = []() {
                if constexpr(std::is_same_v<typename Problem::InOutDataType, fp16_t> &&
                             std::is_same_v<typename Problem::GemmAccDataType, float>)
                {
                    return WarpGemmMfmaF16F16F32M16N16K16TransposedCDistribution{};
                }
                else if constexpr(std::is_same_v<typename Problem::InOutDataType, bf16_t> &&
                                  std::is_same_v<typename Problem::GemmAccDataType, float>)
                {
                    return WarpGemmMfmaBf16Bf16F32M16N16K16TransposedCDistribution{};
                }
            }();

            // clang-format off
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<0>{}) == decltype(warp_gemm)::kM, "Check failed!");
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<1>{}) == decltype(warp_gemm)::kN, "Check failed!");
            static_assert(Problem::MultiheadAttentionTileShape::Gemm0WarpTile::at(number<2>{}) == decltype(warp_gemm)::kK, "Check failed!");
            // clang-format on 
	
            using BlockGemmPolicy = BlockGemmARegBSmemCRegV1CustomPolicy<
                typename Problem::InOutDataType,
                typename Problem::InOutDataType,
                typename Problem::GemmAccDataType,
                typename Problem::MultiheadAttentionTileShape::Gemm0BlockWarps,
                decltype(warp_gemm)>;

            return BlockGemmARegBSmemCRegOneWarpV1<BlockGemmProblem, BlockGemmPolicy>{};
        }
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeB1DramTileDistribution()
    {
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN1; 
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK1; 

        constexpr index_t N1 = GetAlignmentB1<Problem>(); 
        constexpr index_t N0 = kNPerBlock / N1;

        constexpr index_t K1 = get_warp_size() / N0; 
        constexpr index_t K0 = Problem::kBlockSize / get_warp_size(); 
        constexpr index_t K2 = kKPerBlock / (K0 * K1); 

        return make_static_tile_distribution(
            tile_distribution_encoding<sequence<0>,
                                       tuple<sequence<K0, K1, K2>, sequence<N0, N1>>,
                                       tuple<sequence<1>, sequence<1, 2>>,
                                       tuple<sequence<0>, sequence<1, 0>>,
                                       sequence<1, 2>,
                                       sequence<2, 1>>{});
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeShuffledB1RegBlockDescriptor()
    {
        // N Major
        constexpr index_t kBlockSize = Problem::kBlockSize;

        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN1;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK1;

        constexpr index_t N1 = GetAlignmentB1<Problem>();
        constexpr index_t N0 = kNPerBlock / N1;

        constexpr index_t K1 = get_warp_size() / N0;
        constexpr index_t K0 = kBlockSize / get_warp_size();
        constexpr index_t K2 = kKPerBlock / (K1 * K0);

        return make_static_tile_distribution(
            tile_distribution_encoding<sequence<0>,
                                       tuple<sequence<K0, K1, K2>, sequence<N0, N1>>,
                                       tuple<sequence<1>, sequence<1, 2>>,
                                       tuple<sequence<0>, sequence<1, 0>>,
                                       sequence<2, 1>,
                                       sequence<1, 2>>{});
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeB1LdsWriteBlockDescriptor()
    {
        constexpr index_t kBlockSize = Problem::kBlockSize;
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN1;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK1;
        
        constexpr index_t N1 = GetAlignmentB1<Problem>();
        constexpr index_t N0 = kNPerBlock / N1;

        constexpr index_t K1 = get_warp_size() / N0;
        constexpr index_t K0 = kBlockSize / get_warp_size();
        constexpr index_t K2 = kKPerBlock / (K1 * K0);

        constexpr auto b1t_lds_block_desc_0 = make_naive_tensor_descriptor(
            make_tuple(number<kKPerBlock / K2>{}, number<kNPerBlock>{}, number<K2>{}),
            make_tuple(number<(kNPerBlock) * K2>{}, number<K2>{}, number<1>{}),
            number<K2>{},
            number<1>{});

        return  transform_tensor_descriptor(
            b1t_lds_block_desc_0,
            make_tuple(
                make_pass_through_transform(number<kNPerBlock>{}),
                make_merge_transform(make_tuple(number<kKPerBlock / K2>{}, number<K2>{}))),
            make_tuple(sequence<1>{}, sequence<0, 2>{}),
            make_tuple(sequence<1>{}, sequence<0>{}));
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto MakeB1TLdsBlockDescriptor()
    {        
        constexpr index_t kBlockSize = Problem::kBlockSize;
        constexpr index_t kNPerBlock = Problem::MultiheadAttentionTileShape::kN1;
        constexpr index_t kKPerBlock = Problem::MultiheadAttentionTileShape::kK1;
        
        constexpr index_t N1 = GetAlignmentB1<Problem>();
        constexpr index_t N0 = kNPerBlock / N1;

        constexpr index_t K1 = get_warp_size() / N0;
        constexpr index_t K0 = kBlockSize / get_warp_size();
        constexpr index_t K2 = kKPerBlock / (K1 * K0);

        constexpr auto b1t_lds_block_desc_0 = make_naive_tensor_descriptor(
            make_tuple(number<kKPerBlock / K2>{}, number<kNPerBlock>{}, number<K2>{}),
            make_tuple(number<(kNPerBlock) * K2>{}, number<K2>{}, number<1>{}),
            number<K2>{},
            number<1>{});

        constexpr auto b1t_lds_block_desc = transform_tensor_descriptor(
            b1t_lds_block_desc_0,
            make_tuple(
                make_pass_through_transform(number<kNPerBlock>{}),
                make_merge_transform(make_tuple(number<kKPerBlock / K2>{}, number<K2>{}))),
            make_tuple(sequence<1>{}, sequence<0, 2>{}),
            make_tuple(sequence<0>{}, sequence<1>{}));

        return b1t_lds_block_desc;
    }

    template <typename Problem>
    CK_TILE_HOST_DEVICE static constexpr auto GetPB1TBlockGemm()
    {
        using BlockGemmProblem =
            BlockGemmPipelineProblem<typename Problem::InOutDataType,
                                     typename Problem::InOutDataType,
                                     typename Problem::GemmAccDataType,
                                     Problem::kBlockSize,
                                     TileGemmShape<Problem::MultiheadAttentionTileShape::kM,
                                                   Problem::MultiheadAttentionTileShape::kN1,
                                                   Problem::MultiheadAttentionTileShape::kK1>>;

        constexpr auto warp_gemm = []() {
            if constexpr(std::is_same_v<typename Problem::InOutDataType, fp16_t> &&
                         std::is_same_v<typename Problem::GemmAccDataType, float>)
            {
                return WarpGemmMfmaF16F16F32M16N16K16TransposedCDistribution{};
            }
            else if constexpr(std::is_same_v<typename Problem::InOutDataType, bf16_t> &&
                              std::is_same_v<typename Problem::GemmAccDataType, float>)
            {
                return WarpGemmMfmaBf16Bf16F32M16N16K16TransposedCDistribution{};
            }
        }();

        // clang-format off
        static_assert(Problem::MultiheadAttentionTileShape::Gemm1WarpTile::at(number<0>{}) == decltype(warp_gemm)::kM, "Check failed!");
        static_assert(Problem::MultiheadAttentionTileShape::Gemm1WarpTile::at(number<1>{}) == decltype(warp_gemm)::kN, "Check failed!");
        static_assert(Problem::MultiheadAttentionTileShape::Gemm1WarpTile::at(number<2>{}) == decltype(warp_gemm)::kK, "Check failed!");
        // clang-format on 

        using BlockGemmPolicy = BlockGemmARegBSmemCRegV1CustomPolicy<
            typename Problem::InOutDataType,
            typename Problem::InOutDataType,
            typename Problem::GemmAccDataType,
            typename Problem::MultiheadAttentionTileShape::Gemm1BlockWarps,
            decltype(warp_gemm)>;

        return BlockGemmARegBSmemCRegV1<BlockGemmProblem, BlockGemmPolicy>{};
    }
};

} // namespace ck_tile


BUILD=/code/composable_kernel-internal/build
EXE=$BUILD/bin/tile_example_multihead_attention

#for prec in "fp16" "bf16"; do
for prec in "fp16"; do
    for seq in 1 141; do
        for a_seq in 1 16 32 48 64 128 256; do
            for dd in "n"; do 
                for nhead in 8; do 
                    for hsize in 16 32 64 128 256; do 
                        for b1_hsize in 16 32 64 128 256; do
                            for maskmax in -1 0 1 5; do
                                for qmaskmax in -1 0 1 5; do
                                    for nidx in 1 8 40; do
                                        for batch in 1 8 10 40; do
                                        for do_gather in 1 0; do
                                            if [ $batch -gt $nidx ] && [ $nidx -ne 1 ]; then
                                                continue
                                            fi
                                            if [ "$do_gather" -eq 0 ]; then
                                                if !([ "$batch" -eq 1 ] || [ "$nidx" -eq 1 ] || [ "$batch" -eq "$nidx" ]); then
                                                    continue
                                                fi
                                            elif [ "$do_gather" -eq 1 ]; then
                                                if !([ "$nidx" -ge "$batch" ] && [ "$batch" -gt 1 ]); then
                                        
                                                    continue
                                                fi
                                            fi
                                            

                                            cmdline="$EXE -v=1 -prec=$prec -b=$batch -nidx=$nidx -nhead=$nhead -hsize=$hsize -seq=$seq -a_seq=$a_seq -init=$dd -seed=123 -perf=0 -maskmax=$maskmax -do_gather=$do_gather"
                                            $EXE -v=1 -prec=$prec -b=$batch -nidx=$nidx -nhead=$nhead -hsize=$hsize -seq=$seq -init=u -seed=123 -perf=0 -maskmax=$maskmax -qmaskmax=$qmaskmax -do_gather=$do_gather
                                            if [ $? -eq 0 ]; then 
                                                echo "Passed: $cmdline" 
                                            else
                                                #if [ $batch -lt $nidx ]; then
                                                echo "Failed: $cmdline"
                                                #fi
                                            fi
                                        done
                                    done
                                done
                            done
                        done
                        done
                    done
                done
            done
        done
    done
done
// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2023, Advanced Micro Devices, Inc. All rights reserved.

#include <ck_tile/core.hpp>

#include "multihead_attention_headdim_switch.hpp"
#include "multihead_attention_dispatch.hpp"

// clang-format off
// TileM=16

//add for kmask=true, qmask=true

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=32
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=48
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=64
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=128
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=256
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  16, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  32, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  64, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 16, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 32, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 64, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 128, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 256, true, true>(const MultiheadAttentionParams& param, hipStream_t stream);

//add for kmask = true, qmask = false
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);


extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=32
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=48
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=64
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=128
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=256
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  16, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  32, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  64, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 16, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 32, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 64, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 128, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 256, true, false>(const MultiheadAttentionParams& param, hipStream_t stream);


//add for kmask=false, qmask=true
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);


extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=32
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=48
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=64
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=128
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=256
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  16, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  32, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  64, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 16, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 32, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 64, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 128, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 256, false, true>(const MultiheadAttentionParams& param, hipStream_t stream);

//add for kmask=false, qmask=false
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);


extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  1, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  16, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=32
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  32, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=48
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  48, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=64
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  64, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=128
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  128, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

// TileM=256
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  16, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  32, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256,  64, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 16, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 32, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 64, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 128, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 16, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 32, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 64, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 128, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);
extern template void run_multihead_attention<ck_tile::fp16_t, uint8_t,  256, 256, 256, false, false>(const MultiheadAttentionParams& param, hipStream_t stream);

void multihead_attention_fp16(MultiheadAttentionParams& param, hipStream_t stream)
{   
      const bool do_kmask        = !(param.mask_ptr == nullptr);
      const bool do_qmask        = !(param.qmask_ptr == nullptr);
     
      BOOL_SWITCH_2(
        do_kmask,
        kDoKMask,
        do_qmask,
        kDoQMask,
        [&]{
        if(param.a_seqlen == 1 && param.num_batch==1){
                // Merge ABatch
                    HEAD_SZ_SWITCH_2(param.head_sz, kMaxK, param.b1_head_sz, MaxKN, [&] {
                        run_multihead_attention<ck_tile::fp16_t, uint8_t, 64, kMaxK, MaxKN, kDoKMask, kDoQMask>(param, stream);
                    });
        }
        else  if(param.num_batch!=1 && param.a_seqlen == 1)
        {
                HEAD_SZ_SWITCH_2(param.head_sz, kMaxK, param.b1_head_sz, MaxKN, [&] {
                    run_multihead_attention<ck_tile::fp16_t, uint8_t, 1, kMaxK, MaxKN, kDoKMask, kDoQMask>(param, stream);
                });
        }
        else{
                SEQLEN_HEAD_SZ_SWITCH_2(param.a_seqlen, kM, param.head_sz, kMaxK, param.b1_head_sz, MaxKN, [&] {
                    run_multihead_attention<ck_tile::fp16_t, uint8_t, kM, kMaxK, MaxKN, kDoKMask, kDoQMask>(param, stream);
            });
        }
    });
};

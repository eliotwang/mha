// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <ck_tile/core.hpp>
#include <stdexcept>

#define HEAD_SZ_SWITCH(HEAD_SZ, CONST_NAME, ...)                       \
    [&] {                                                              \
        if(HEAD_SZ <= 16)                                              \
        {                                                              \
            constexpr ck_tile::index_t CONST_NAME = 16;                \
            __VA_ARGS__();                                             \
        }                                                              \
        else if(HEAD_SZ <= 32)                                         \
        {                                                              \
            constexpr ck_tile::index_t CONST_NAME = 32;                \
            __VA_ARGS__();                                             \
        }                                                              \
        else if(HEAD_SZ <= 64)                                         \
        {                                                              \
            constexpr ck_tile::index_t CONST_NAME = 64;                \
            __VA_ARGS__();                                             \
        }                                                              \
        else if(HEAD_SZ <= 128)                                        \
        {                                                              \
            constexpr ck_tile::index_t CONST_NAME = 128;               \
            __VA_ARGS__();                                             \
        }                                                              \
        else if(HEAD_SZ <= 256)                                        \
        {                                                              \
            constexpr ck_tile::index_t CONST_NAME = 256;               \
            __VA_ARGS__();                                             \
        }                                                              \
        else                                                           \
        {                                                              \
            throw std::runtime_error("Head-dim sizes not supported!"); \
        }                                                              \
    }()

#define HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME1, B1_HEAD_SZ, CONST_NAME2, ...) \
    [&] {                                                                    \
        if(HEAD_SZ <= 16)                                                    \
        {                                                                    \
            constexpr ck_tile::index_t CONST_NAME1 = 16;                     \
            HEAD_SZ_SWITCH(B1_HEAD_SZ, CONST_NAME2, ##__VA_ARGS__);          \
        }                                                                    \
        else if(HEAD_SZ <= 32)                                               \
        {                                                                    \
            constexpr ck_tile::index_t CONST_NAME1 = 32;                     \
            HEAD_SZ_SWITCH(B1_HEAD_SZ, CONST_NAME2, ##__VA_ARGS__);          \
        }                                                                    \
        else if(HEAD_SZ <= 64)                                               \
        {                                                                    \
            constexpr ck_tile::index_t CONST_NAME1 = 64;                     \
            HEAD_SZ_SWITCH(B1_HEAD_SZ, CONST_NAME2, ##__VA_ARGS__);          \
        }                                                                    \
        else if(HEAD_SZ <= 128)                                              \
        {                                                                    \
            constexpr ck_tile::index_t CONST_NAME1 = 128;                    \
            HEAD_SZ_SWITCH(B1_HEAD_SZ, CONST_NAME2, ##__VA_ARGS__);          \
        }                                                                    \
        else if(HEAD_SZ <= 256)                                              \
        {                                                                    \
            constexpr ck_tile::index_t CONST_NAME1 = 256;                    \
            HEAD_SZ_SWITCH(B1_HEAD_SZ, CONST_NAME2, ##__VA_ARGS__);          \
        }                                                                    \
    }()

#define SEQLEN_HEAD_SZ_SWITCH_2(                                                            \
    SEQLEN, CONST_NAME1, HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ...)                \
    [&] {                                                                                   \
        if(SEQLEN <= 16)                                                                    \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 16;                                    \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
        else if(SEQLEN <= 32)                                                               \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 32;                                    \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
        else if(SEQLEN <= 48)                                                               \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 48;                                    \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
        else if(SEQLEN <= 64)                                                               \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 64;                                    \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
        else if(SEQLEN <= 128)                                                              \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 128;                                   \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
        else                                                                                \
        {                                                                                   \
            constexpr ck_tile::index_t CONST_NAME1 = 256;                                   \
            HEAD_SZ_SWITCH_2(HEAD_SZ, CONST_NAME2, B1_HEAD_SZ, CONST_NAME3, ##__VA_ARGS__); \
        }                                                                                   \
    }()

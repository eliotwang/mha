#!/ bin / bash
'''
BUILD=/workspace/common/dcc/multihead_new/composable_kernel-internal/build
EXE=$BUILD/bin/tile_example_multihead_attention

cmd="$EXE -v=1 -prec=fp16 -b=1000 -nidx=1000 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=32 -seq=48 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1000 -nidx=1000 -a_seq=1 -nhead=8 -hsize=16 -seq=48 -b1_hsize=32 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=500 -nidx=500 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=8 -seq=200 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=500 -nidx=500 -a_seq=1 -nhead=8 -hsize=16 -seq=200 -b1_hsize=8 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=100 -nidx=100 -a_seq=1 -nhead=4 -hsize=32 -b1_hsize=32 -seq=512 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=100 -nidx=100 -a_seq=1 -nhead=4 -hsize=32 -seq=512 -b1_hsize=32 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1500 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=32 -seq=200 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1500 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -seq=200 -b1_hsize=32 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1 -nidx=500 -a_seq=200 -nhead=8 -hsize=16 -b1_hsize=8 -seq=200 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1 -nidx=500 -a_seq=200 -nhead=8 -hsize=16 -seq=200 -b1_hsize=8 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1 -nidx=669 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=16 -seq=48 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1 -nidx=669 -a_seq=1 -nhead=8 -hsize=16 -seq=48 -b1_hsize=16 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=32 -seq=200 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -seq=200 -b1_hsize=32 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -b1_hsize=16 -seq=48 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=1 -nhead=8 -hsize=16 -seq=48 -b1_hsize=16 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10


cmd="$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=64 -nhead=8 -hsize=16 -b1_hsize=16 -seq=64 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10"
echo $cmd
$EXE -v=1 -prec=fp16 -b=1 -nidx=1500 -a_seq=64 -nhead=8 -hsize=16 -seq=64 -b1_hsize=16 -init=u -input_layout=0 -seed=123 -perf=1 -maskmax=5 -qmaskmax=10
'''

BUILD=/workspace/common/dcc/multihead_new/composable_kernel-internal/build
EXE=$BUILD/bin/tile_example_multihead_attention

while read -r line; do
    # 使用 eval 来解析每行的变量赋值
    eval "$line"
    
    # 根据 HeadSplited 的值设置 input_layout
    if [ "$HeadSplited" = "true" ]; then
        input_layout=0
    else
        input_layout=1
    fi

    # 生成命令并打印
    cmd="$EXE -v=1 -prec=fp16 -nidx=$Bq -b=$Bkv -a_seq=$Tq -seq=$Tkv -nhead=$HeadNum -hsize=$qkHeadSz -b1_hsize=$vHeadSz -init=u -seed=123 -perf=1 -maskmax=5 -qmaskmax=10 -input_layout=$input_layout"
    echo "$cmd"

    # 执行命令
    eval "$cmd"
done <<EOF
Bq=1500 Bkv=1500 Tq=14 Tkv=14 HeadNum=8 qkHeadSz=128 vHeadSz=256 HeadSplited=false
Bq=1500 Bkv=1500 Tq=14 Tkv=14 HeadNum=8 qkHeadSz=128 vHeadSz=256 HeadSplited=true
Bq=1500 Bkv=1500 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=44 vHeadSz=44 HeadSplited=false
Bq=1500 Bkv=1500 Tq=10 Tkv=10 HeadNum=8 qkHeadSz=44 vHeadSz=44 HeadSplited=true
Bq=1000 Bkv=1000 Tq=48 Tkv=48 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=false
Bq=1000 Bkv=1000 Tq=48 Tkv=48 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=true
Bq=1000 Bkv=1000 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=false
Bq=1000 Bkv=1000 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=true
Bq=854 Bkv=854 Tq=48 Tkv=48 HeadNum=8 qkHeadSz=32 vHeadSz=32 HeadSplited=false
Bq=854 Bkv=854 Tq=48 Tkv=48 HeadNum=8 qkHeadSz=32 vHeadSz=32 HeadSplited=true
Bq=600 Bkv=20 Tq=1 Tkv=100 HeadNum=4 qkHeadSz=16 vHeadSz=32 HeadSplited=false
Bq=600 Bkv=20 Tq=1 Tkv=100 HeadNum=4 qkHeadSz=16 vHeadSz=32 HeadSplited=true
Bq=500 Bkv=1 Tq=200 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=8 HeadSplited=false
Bq=500 Bkv=1 Tq=200 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=8 HeadSplited=true
Bq=1 Bkv=700 Tq=1 Tkv=256 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=false
Bq=1 Bkv=700 Tq=1 Tkv=256 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=true
Bq=669 Bkv=1 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=false
Bq=669 Bkv=1 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=true
Bq=100 Bkv=100 Tq=1 Tkv=512 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=false
Bq=100 Bkv=100 Tq=1 Tkv=512 HeadNum=4 qkHeadSz=32 vHeadSz=32 HeadSplited=true
Bq=1500 Bkv=1 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=false
Bq=1500 Bkv=1 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=true
Bq=1500 Bkv=1 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=false
Bq=1500 Bkv=1 Tq=1 Tkv=48 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=true
Bq=1500 Bkv=1 Tq=64 Tkv=64 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=false
Bq=1500 Bkv=1 Tq=64 Tkv=64 HeadNum=8 qkHeadSz=16 vHeadSz=16 HeadSplited=true
Bq=1500 Bkv=1500 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=false
Bq=1500 Bkv=1500 Tq=1 Tkv=200 HeadNum=8 qkHeadSz=16 vHeadSz=32 HeadSplited=true
EOF

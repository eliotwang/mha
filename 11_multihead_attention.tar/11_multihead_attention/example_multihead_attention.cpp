// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#include <array>
#include <cstring>
#include <functional>
#include <numeric>
#include <ostream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
#include <random>

#include <ck_tile/host/host_tensor.hpp>
#include <ck_tile/host/fill.hpp>
#include <ck_tile/host/device_memory.hpp>
#include <ck_tile/host/stream_config.hpp>
#include <ck_tile/host/arg_parser.hpp>
#include <ck_tile/host/hip_check_error.hpp>
#include <ck_tile/host/check_err.hpp>
#include <ck_tile/host/timer.hpp>

#include "multihead_attention_params.hpp"
#include "multihead_attention_setting.hpp"
#include "reference_multihead_attention.hpp"
#include "ck_tile/core/numeric/type_convert.hpp"

extern void multihead_attention_fp16(MultiheadAttentionParams& param, hipStream_t stream);

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& v)
{
    using size_type = typename std::vector<T>::size_type;

    os << "[";
    for(size_type idx = 0; idx < v.size(); ++idx)
    {
        if(0 < idx)
        {
            os << ", ";
        }
        os << v[idx];
    }
    return os << "]";
}

auto create_args(int argc, char* argv[])
{
    ck_tile::ArgParser arg_parser;

    // clang-format off
    arg_parser.insert("v", "1", "weather do CPU validation or not")
        .insert("prec", "fp16", "data type. fp16")
        .insert("b", "12", "batch size")
        .insert("nidx", "8", "number of indices for accessing the batches")
        .insert("nhead", "4", "number of heads")
        .insert("hsize", "64", "headdim size")
        .insert("b1_hsize", "64", "b1 headdim_size")
        .insert("seq", "1024", "seqlen, the length of the dimension where softmax is used on")
        .insert("a_seq", "1", "a_seqlen, the length of the dimentions for A matrix")
        .insert("init", "u", "init method for input tensor values, u, uniform random float values, n, normalized random float values")
	    .insert("seed", "13579", "seed by the uniform or normal distribution generator")
        .insert("perf", "0", "weather measure execution time or not")
	    .insert("maskmax", "0", "used to set mask values to random [0, maskmax), maskmax should in [0, 128], 0 means set all values to 1, 1 means set all values to 0, -1 means no mask")
    	.insert("qmaskmax", "0", "used to set mask values to random [0, qmaskmax), qmaskmax should in [0, 128], 0 means set all values to 1, 1 means set all values to 0, -1 means no mask")
        .insert("input_layout", "0", "input tensor layout, 0: [nhead, batch, seqlen, hsize]; 1: [batch, seqlen, nhead, hsize];")
        .insert("do_gather", "0", "Whether to perform gather: 0: Do not perform gather, 1: Perform gather.");
    // clang-format on
    bool result = arg_parser.parse(argc, argv);
    return std::make_tuple(result, arg_parser);
}

// threshold for different dtypes
template <typename DataType>
auto get_elimit()
{
    double rtol = 2e-3;
    double atol = 2e-3;

    return ck_tile::make_tuple(rtol, atol);
}

template <>
auto get_elimit<ck_tile::bf16_t>()
{
    double rtol = 1e-2;
    double atol = 1e-2;
    return ck_tile::make_tuple(rtol, atol);
}

template <typename InOutDataType, typename MaskDataType>
bool run(const ck_tile::ArgParser& arg_parser)
{
    int do_validation           = arg_parser.get_int("v");
    ck_tile::index_t batches    = arg_parser.get_int("b");
    ck_tile::index_t nindex     = arg_parser.get_int("nidx");
    ck_tile::index_t nhead      = arg_parser.get_int("nhead");
    ck_tile::index_t head_sz    = arg_parser.get_int("hsize");
    ck_tile::index_t b1_head_sz = arg_parser.get_int("b1_hsize");
    ck_tile::index_t seqlen     = arg_parser.get_int("seq");
    ck_tile::index_t a_seqlen   = arg_parser.get_int("a_seq");
    std::string init_method     = arg_parser.get_str("init");
    ck_tile::index_t seed       = arg_parser.get_int("seed");
    bool measure_perf           = static_cast<bool>(arg_parser.get_int("perf"));
    int mask_max                = arg_parser.get_int("maskmax");
    int qmask_max               = arg_parser.get_int("qmaskmax");
    int input_layout            = arg_parser.get_int("input_layout");
    bool do_gather              = static_cast<bool>(arg_parser.get_int("do_gather"));

    if(mask_max > 128)
    {
        std::cerr << "Invalid maskmax argument, mask max scope should be in [1, 128]!" << std::endl;
        return false;
    };

    if(qmask_max > 128)
    {
        std::cerr << "Invalid qmaskmax argument, qmask max scope should be in [1, 128]!"
                  << std::endl;
        return false;
    };

    if(input_layout != 0 and input_layout != 1)
    {
        std::cerr << "Invalid input_layout argument, input_layout scope should be in 0 or 1!"
                  << std::endl;
        return false;
    };

    if(do_gather && (!(nindex >= batches && batches > 1)))
    {
        std::cerr << "Error: When do_gather is true, nindex must be greater than or equal to "
                     "batches and batches must be greater than 1!"
                  << std::endl;
        return false;
    }
    if((!do_gather) && (nindex > batches && batches > 1))
    {
        std::cerr << "Error: When nindex is greater than batches and batches is greater than 1, "
                     "do_gather muse be true!"
                  << std::endl;
        return false;
    }

    ck_tile::index_t output_batch = max(nindex, batches);

    auto a_host = input_layout == 0
                      ? ck_tile::HostTensor<InOutDataType>(
                            std::array<ck_tile::index_t, 4>{nhead, nindex, a_seqlen, head_sz})
                      : ck_tile::HostTensor<InOutDataType>(
                            std::array<ck_tile::index_t, 4>{nindex, a_seqlen, nhead, head_sz});

    auto b0_host = input_layout == 0
                       ? ck_tile::HostTensor<InOutDataType>(
                             std::array<ck_tile::index_t, 4>{nhead, batches, seqlen, head_sz})
                       : ck_tile::HostTensor<InOutDataType>(
                             std::array<ck_tile::index_t, 4>{batches, seqlen, nhead, head_sz});

    auto b1_host = input_layout == 0
                       ? ck_tile::HostTensor<InOutDataType>(
                             std::array<ck_tile::index_t, 4>{nhead, batches, seqlen, b1_head_sz})
                       : ck_tile::HostTensor<InOutDataType>(
                             std::array<ck_tile::index_t, 4>{batches, seqlen, nhead, b1_head_sz});

    ck_tile::HostTensor<InOutDataType> d_host_ref(
        std::array<ck_tile::index_t, 4>{output_batch, a_seqlen, nhead, b1_head_sz});

    ck_tile::HostTensor<MaskDataType> mask_host(std::array<ck_tile::index_t, 2>{batches, seqlen});

    ck_tile::HostTensor<MaskDataType> qmask_host(std::array<ck_tile::index_t, 2>{nindex, a_seqlen});

    std::vector<int> indices_host;
    // bool do_gather = (nindex >= batches && batches > 1);
    bool do_kmask = true; // mask_max >= 0;
    bool do_qmask = qmask_max >= 0;

    if(do_gather)
    {

        std::vector<int> indices_tmp;

        for(int i = 0; i < output_batch; i++)
            indices_tmp.push_back(i);

        std::random_device rd;
        std::mt19937 g(rd());

        if(!(nindex >= batches && batches > 1))
        {
            printf("Unsupported batch setting for Gather!\n");
            return false;
        }

        if(nindex == batches)
        {
            std::shuffle(indices_tmp.begin(), indices_tmp.end(), g);
            indices_host.insert(indices_host.end(), indices_tmp.begin(), indices_tmp.end());
        }
        else
        {
            for(int i = 0; i < output_batch; i++)
            {
                std::uniform_int_distribution<> dis(0, min(nindex, batches) - 1);
                int random_number = dis(g);
                indices_host.push_back(indices_tmp[random_number]);
            };
        }
    }
    else
    {
        if(!((nindex == 1) || (batches == 1) || (nindex >= batches)))
        {
            printf("Unsupported batch setting!\n");
            return false;
        }
    }

    if(init_method == "u")
    {
        ck_tile::FillUniformDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(a_host);
        ck_tile::FillUniformDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b0_host);
        ck_tile::FillUniformDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b1_host);
    }
    else if(init_method == "n")
    {
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(a_host);
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b0_host);
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b1_host);
    }
    else if(init_method == "1")
    {
        ck_tile::FillConstant<InOutDataType>{1}(a_host);
        ck_tile::FillConstant<InOutDataType>{1}(b0_host);
        ck_tile::FillConstant<InOutDataType>{1}(b1_host);
    }
    else if(init_method == "2")
    {
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(a_host);
        ck_tile::FillConstant<InOutDataType>{1}(b0_host);
        ck_tile::FillConstant<InOutDataType>{1}(b1_host);
    }
    else if(init_method == "3")
    {
        ck_tile::FillConstant<InOutDataType>{1}(a_host);
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b0_host);
        ck_tile::FillConstant<InOutDataType>{1}(b1_host);
    }
    else if(init_method == "4")
    {
        ck_tile::FillConstant<InOutDataType>{1}(a_host);
        ck_tile::FillConstant<InOutDataType>{1}(b0_host);
        ck_tile::FillNormalDistributionIntegerValue<InOutDataType>{-2.f, 2.f, seed}(b1_host);
    }

    if(mask_max == 0 || mask_max == -1)
        ck_tile::FillConstant<MaskDataType>{1}(mask_host);
    else if(mask_max == 1)
        ck_tile::FillConstant<MaskDataType>{0}(mask_host);
    else if(mask_max > 1)
        ck_tile::FillUniformDistributionIntegerValue<MaskDataType>{
            0, static_cast<float>(mask_max - 1), seed + 1111}(mask_host);

    if(qmask_max == 0)
        ck_tile::FillConstant<MaskDataType>{1}(qmask_host);
    else if(qmask_max == 1)
        ck_tile::FillConstant<MaskDataType>{0}(qmask_host);
    else if(qmask_max > 1)
        ck_tile::FillUniformDistributionIntegerValue<MaskDataType>{
            0, static_cast<float>(qmask_max - 1), seed + 1111}(qmask_host);

    ck_tile::DeviceMem a_dev(a_host.get_element_space_size_in_bytes());
    ck_tile::DeviceMem b0_dev(b0_host.get_element_space_size_in_bytes());
    ck_tile::DeviceMem b1_dev(b1_host.get_element_space_size_in_bytes());
    ck_tile::DeviceMem d_dev(d_host_ref.get_element_space_size_in_bytes());
    ck_tile::DeviceMem mask_dev(mask_host.get_element_space_size_in_bytes());
    ck_tile::DeviceMem qmask_dev(qmask_host.get_element_space_size_in_bytes());

    ck_tile::DeviceMem indices_dev(output_batch * sizeof(int));

    a_dev.ToDevice(a_host.data());
    b0_dev.ToDevice(b0_host.data());
    b1_dev.ToDevice(b1_host.data());
    mask_dev.ToDevice(mask_host.data());
    qmask_dev.ToDevice(qmask_host.data());

    if(indices_host.size() > 0)
        indices_dev.ToDevice(indices_host.data());

    MultiheadAttentionParams params;

    params.a_ptr       = a_dev.GetDeviceBuffer();
    params.b0_ptr      = b0_dev.GetDeviceBuffer();
    params.mask_ptr    = do_kmask ? mask_dev.GetDeviceBuffer() : nullptr;
    params.qmask_ptr   = do_qmask ? qmask_dev.GetDeviceBuffer() : nullptr;
    params.indices_ptr = do_gather ? indices_dev.GetDeviceBuffer() : nullptr;
    params.b1_ptr      = b1_dev.GetDeviceBuffer(); // workspace
    params.d_ptr       = d_dev.GetDeviceBuffer();
    params.num_batch   = batches;
    params.num_index   = nindex;
    params.seqlen      = seqlen;
    params.a_seqlen    = a_seqlen;
    params.num_head    = nhead;
    params.head_sz     = head_sz;
    params.b1_head_sz  = b1_head_sz;

    if(input_layout == 0)
    {
        params.a_nhead_stride  = a_host.mDesc.get_strides()[0];
        params.a_batch_stride  = a_host.mDesc.get_strides()[1];
        params.a_seq_stride    = a_host.mDesc.get_strides()[2];
        params.b0_nhead_stride = b0_host.mDesc.get_strides()[0];
        params.b0_batch_stride = b0_host.mDesc.get_strides()[1];
        params.b0_seq_stride   = b0_host.mDesc.get_strides()[2];
        params.b1_nhead_stride = b1_host.mDesc.get_strides()[0];
        params.b1_batch_stride = b1_host.mDesc.get_strides()[1];
        params.b1_seq_stride   = b1_host.mDesc.get_strides()[2];
    }
    else if(input_layout == 1)
    {
        params.a_batch_stride  = a_host.mDesc.get_strides()[0];
        params.a_seq_stride    = a_host.mDesc.get_strides()[1];
        params.a_nhead_stride  = a_host.mDesc.get_strides()[2];
        params.b0_batch_stride = b0_host.mDesc.get_strides()[0];
        params.b0_seq_stride   = b0_host.mDesc.get_strides()[1];
        params.b0_nhead_stride = b0_host.mDesc.get_strides()[2];
        params.b1_batch_stride = b1_host.mDesc.get_strides()[0];
        params.b1_seq_stride   = b1_host.mDesc.get_strides()[1];
        params.b1_nhead_stride = b1_host.mDesc.get_strides()[2];
    }

    params.mask_batch_stride  = mask_host.mDesc.get_strides()[0];
    params.qmask_batch_stride = qmask_host.mDesc.get_strides()[0];
    params.d_batch_stride     = d_host_ref.mDesc.get_strides()[0];
    params.d_seq_stride       = d_host_ref.mDesc.get_strides()[1];
    params.d_nhead_stride     = d_host_ref.mDesc.get_strides()[2];

    hipStream_t stream;

    HIP_CHECK_ERROR(hipStreamCreate(&stream));

    if constexpr(std::is_same<InOutDataType, ck_tile::fp16_t>::value &&
                 std::is_same<MaskDataType, uint8_t>::value)
    {
        multihead_attention_fp16(params, stream);
    }

    bool res = true;

    if(do_validation)
    {
        using GemmAccDataType =
            typename MultiheadAttentionTypeConfig<InOutDataType>::GemmAccDataType;
        using SMComputeDataType =
            typename MultiheadAttentionTypeConfig<InOutDataType>::SMComputeDataType;

        ck_tile::reference_multihead_attention<InOutDataType,
                                               MaskDataType,
                                               GemmAccDataType,
                                               SMComputeDataType>::Run(a_host,
                                                                       b0_host,
                                                                       mask_host,
                                                                       qmask_host,
                                                                       indices_host,
                                                                       b1_host,
                                                                       d_host_ref,
                                                                       head_sz,
                                                                       b1_head_sz,
                                                                       seqlen,
                                                                       a_seqlen,
                                                                       batches,
                                                                       nindex,
                                                                       nhead,
                                                                       input_layout,
                                                                       do_kmask,
                                                                       do_qmask,
                                                                       do_gather);

        ck_tile::HostTensor<InOutDataType> d_host(
            std::array<ck_tile::index_t, 4>{output_batch, a_seqlen, nhead, b1_head_sz});

        d_dev.FromDevice(d_host.data());

        auto [rtol, atol] = get_elimit<InOutDataType>();

        res = ck_tile::check_err(
            d_host, d_host_ref, std::string("multihead_attention output error"), atol, rtol);
        if(res)
            printf("=====pass======\n");
    }

    if(measure_perf)
    {
        ck_tile::gpu_timer timer{};

        timer.start(stream);
        for(int i = 0; i < 100; i++)
        {
            if constexpr(std::is_same<InOutDataType, ck_tile::fp16_t>::value)
            {
                multihead_attention_fp16(params, stream);
            }
        }
        timer.stop(stream);

        auto us = timer.duration() / 100 * 1000;

        std::cout << "ProblemSize |Bq=" << nindex << " |Bkv=" << batches << " |Tq=" << a_seqlen
                  << " |Tkv=" << seqlen << " |HeadNum=" << nhead << " |qkHeadSz=" << head_sz
                  << " |vHeadSz=" << b1_head_sz << std::endl;
        std::cout << "Average execution time of the multihead_attention operator is " << us << " us"
                  << std::endl;
    }

    return res;
}

int main(int argc, char* argv[])
{
    auto [result, arg_parser] = create_args(argc, argv);
    if(!result)
    {
        std::cerr << "Invalid arguments, Failed to parse!" << std::endl;
        return -1;
    }

    const std::string data_type = arg_parser.get_str("prec");
    if(data_type == "fp16")
    {
        return run<ck_tile::half_t, uint8_t>(arg_parser) ? 0 : -2;
    }

    return -3;
}

// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <ck_tile/core.hpp>

#include "multihead_attention_pipeline_small_k0_loop.hpp"
#include "multihead_attention_pipeline_big_k0_loop.hpp"

// clang-format off
// MultiheadAttention problem is solved by one kernel, which takes A/B0/B1/mask tensor and indices array as input, do the following:
// S[num_batch, num_head, seqlen] = A[num_batch, num_head, head_sz] @ BOT[num_batch, seqlen, num_head, head_sz]
// P[num_head, num_batch, seqlen] = RowSoftmax(S[num_batch, num_head, seqlen] with filtering by mask before softmax-ing
// D[num_batch, num_head, head_sz] = P[num_head, num_batch, seqlen] @ B1T[num_batch, seqlen, num_head, head_sz]
// The process is very similar to the decoder attention with one Query token in each batch. But one specical point of
// MultiheadAttention is that the accessed batches of B0/B1/mask tensors are specified by an indices vector.
// clang-format on

namespace ck_tile {

template <typename MultiheadAttentionPipeline_, typename EpiloguePipeline_>
struct MultiheadAttentionKernel
{
    using MultiheadAttentionPipeline = ck_tile::remove_cvref_t<MultiheadAttentionPipeline_>;
    using EpiloguePipeline           = ck_tile::remove_cvref_t<EpiloguePipeline_>;
    static constexpr ck_tile::index_t kBlockSize  = MultiheadAttentionPipeline::kBlockSize;
    static constexpr ck_tile::index_t kBlockPerCu = MultiheadAttentionPipeline::kBlockPerCu;
    static_assert(kBlockPerCu > 0);

    using InOutDataType =
        ck_tile::remove_cvref_t<typename MultiheadAttentionPipeline::InOutDataType>;
    using MaskDataType = ck_tile::remove_cvref_t<typename MultiheadAttentionPipeline::MaskDataType>;

    static constexpr bool kPadASeqLen   = MultiheadAttentionPipeline::kPadASeqLen;
    static constexpr bool kPadSeqLen    = MultiheadAttentionPipeline::kPadSeqLen;
    static constexpr bool kPadAB0HeadSz = MultiheadAttentionPipeline::kPadAB0HeadSz;
    static constexpr bool kPadB1DHeadSz = MultiheadAttentionPipeline::kPadB1DHeadSz;
    static constexpr bool kMergeABatch  = MultiheadAttentionPipeline::kMergeABatch;

    // kargs use aggregate initializer, so no explicit constructor provided,
    // user need to use MakeKargs() function to create kargs.
    struct MultiheadAttentionKargs
    {
        const void* a_ptr;
        const void* b0_ptr;
        const void* mask_ptr;
        const void* qmask_ptr;
        const int* indices_ptr;
        const void* b1_ptr;
        void* d_ptr;

        ck_tile::index_t num_index;
        ck_tile::index_t num_batch;
        ck_tile::index_t seqlen;
        ck_tile::index_t a_seqlen;
        ck_tile::index_t num_head;
        ck_tile::index_t head_sz;
        ck_tile::index_t b1_head_sz;
        ck_tile::index_t a_batch_stride;
        ck_tile::index_t a_seq_stride;
        ck_tile::index_t a_nhead_stride;
        ck_tile::index_t b0_batch_stride;
        ck_tile::index_t b0_seq_stride;
        ck_tile::index_t b0_nhead_stride;
        ck_tile::index_t mask_batch_stride;
        ck_tile::index_t qmask_batch_stride;
        ck_tile::index_t b1_batch_stride;
        ck_tile::index_t b1_seq_stride;
        ck_tile::index_t b1_nhead_stride;
        ck_tile::index_t d_batch_stride;
        ck_tile::index_t d_seq_stride;
        ck_tile::index_t d_nhead_stride;
    };

    using Kargs = MultiheadAttentionKargs;

    __host__ static constexpr Kargs MakeKargs(const void* a_ptr,
                                              const void* b0_ptr,
                                              const void* mask_ptr,
                                              const void* qmask_ptr,
                                              const void* indices_ptr,
                                              const void* b1_ptr,
                                              void* d_ptr,
                                              ck_tile::index_t num_index,
                                              ck_tile::index_t num_batch,
                                              ck_tile::index_t seqlen,
                                              ck_tile::index_t a_seqlen,
                                              ck_tile::index_t num_head,
                                              ck_tile::index_t head_sz,
                                              ck_tile::index_t b1_head_sz,
                                              ck_tile::index_t a_batch_stride,
                                              ck_tile::index_t a_seq_stride,
                                              ck_tile::index_t a_nhead_stride,
                                              ck_tile::index_t b0_batch_stride,
                                              ck_tile::index_t b0_seq_stride,
                                              ck_tile::index_t b0_nhead_stride,
                                              ck_tile::index_t mask_batch_stride,
                                              ck_tile::index_t qmask_batch_stride,
                                              ck_tile::index_t b1_batch_stride,
                                              ck_tile::index_t b1_seq_stride,
                                              ck_tile::index_t b1_nhead_stride,
                                              ck_tile::index_t d_batch_stride,
                                              ck_tile::index_t d_seq_stride,
                                              ck_tile::index_t d_nhead_stride)
    {
        Kargs kargs{a_ptr,
                    b0_ptr,
                    mask_ptr,
                    qmask_ptr,
                    reinterpret_cast<const int*>(indices_ptr),
                    b1_ptr,
                    d_ptr,
                    num_index,
                    num_batch,
                    seqlen,
                    a_seqlen,
                    num_head,
                    head_sz,
                    b1_head_sz,
                    a_batch_stride,
                    a_seq_stride,
                    a_nhead_stride,
                    b0_batch_stride,
                    b0_seq_stride,
                    b0_nhead_stride,
                    mask_batch_stride,
                    qmask_batch_stride,
                    b1_batch_stride,
                    b1_seq_stride,
                    b1_nhead_stride,
                    d_batch_stride,
                    d_seq_stride,
                    d_nhead_stride};

        return kargs;
    }

    __host__ static constexpr auto GridSize(const Kargs* pKargs)
    {
        ck_tile::index_t max_batch = max(pKargs->num_index, pKargs->num_batch);
        ck_tile::index_t gridz =
            integer_divide_ceil(pKargs->a_seqlen, MultiheadAttentionPipeline::kM);

        return pKargs->num_batch == 1
                   ? dim3(pKargs->num_head,
                          integer_divide_ceil(pKargs->num_index * pKargs->a_seqlen,
                                              MultiheadAttentionPipeline::kM),
                          1)
                   : dim3(pKargs->num_head, max_batch, gridz);
    }

    CK_TILE_DEVICE static constexpr auto GetTileIndex(const Kargs* pKargs)
    {
        (void)pKargs;
        ck_tile::index_t i_nhead     = blockIdx.x;
        ck_tile::index_t i_batch     = 0;
        ck_tile::index_t i_batch_phy = 0;
        ck_tile::index_t i_seq       = blockIdx.z * MultiheadAttentionPipeline::kM;

        if(pKargs->indices_ptr == nullptr)
        {
            if(pKargs->num_index == 1 && pKargs->num_batch > 1) // q batch =1, broadcast
            {
                i_batch     = 0;
                i_batch_phy = blockIdx.y;
            }
            else if(pKargs->num_index > 1 && pKargs->num_batch == 1) // kv batch =1, broadcast
            {
                // represent the index on batch*a_seqlen
                i_batch     = blockIdx.y * MultiheadAttentionPipeline::kM;
                i_batch_phy = 0;
            }
            else if(pKargs->num_index == pKargs->num_batch) // kv batch = q_batch
            {
                i_batch     = blockIdx.y;
                i_batch_phy = blockIdx.y;
            }
        }
        else if(pKargs->num_batch > 1 && pKargs->num_index >= pKargs->num_batch) // gather
        {
            i_batch     = blockIdx.y;
            i_batch_phy = pKargs->indices_ptr[i_batch];
        }
        return ck_tile::make_tuple(i_batch, i_seq, i_nhead, i_batch_phy);
    }

    __host__ static constexpr auto BlockSize() { return dim3(kBlockSize); }

    CK_TILE_HOST_DEVICE static constexpr ck_tile::index_t GetSmemSize()
    {
        return MultiheadAttentionPipeline::GetSmemSize();
    }

    CK_TILE_DEVICE void operator()(Kargs kargs) const
    {
        using namespace ck_tile;

        // allocate LDS
        __shared__ char smem_ptr[GetSmemSize()];

        // divide the work-groups
        const auto [i_batch, i_seq, i_nhead, i_batch_phy] = GetTileIndex(&kargs);

        if constexpr(!kMergeABatch)
        {
            long_index_t block_offset_a =
                static_cast<long_index_t>(i_batch) * kargs.a_batch_stride +
                static_cast<long_index_t>(i_nhead) * kargs.a_nhead_stride;
            long_index_t block_offset_b0 =
                static_cast<long_index_t>(i_batch_phy) * kargs.b0_batch_stride +
                static_cast<long_index_t>(i_nhead) * kargs.b0_nhead_stride;
            long_index_t block_offset_mask =
                static_cast<long_index_t>(i_batch_phy) * kargs.mask_batch_stride;

            long_index_t block_offset_qmask =
                static_cast<long_index_t>(i_batch) * kargs.qmask_batch_stride;

            long_index_t block_offset_b1 =
                static_cast<long_index_t>(i_batch_phy) * kargs.b1_batch_stride +
                static_cast<long_index_t>(i_nhead) * kargs.b1_nhead_stride;

            long_index_t block_offset_d =
                static_cast<long_index_t>(blockIdx.y) * kargs.d_batch_stride +
                static_cast<long_index_t>(i_nhead) * kargs.d_nhead_stride;

            const InOutDataType* a_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.a_ptr) + block_offset_a;
            const InOutDataType* b0_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.b0_ptr) + block_offset_b0;
            const MaskDataType* mask_ptr =
                reinterpret_cast<const MaskDataType*>(kargs.mask_ptr) + block_offset_mask;
            const MaskDataType* qmask_ptr =
                reinterpret_cast<const MaskDataType*>(kargs.qmask_ptr) + block_offset_qmask;
            const InOutDataType* b1_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.b1_ptr) + block_offset_b1;
            InOutDataType* d_ptr = reinterpret_cast<InOutDataType*>(kargs.d_ptr) + block_offset_d;

            // A0/B0/B1/D/Mask DRAM and DRAM window
            const auto a_dram = [&]() {
                const auto a_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    a_ptr,
                    make_tuple(kargs.a_seqlen, kargs.head_sz),
                    make_tuple(kargs.a_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentA>{},
                    number<1>{});

                return pad_tensor_view(a_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                                  number<MultiheadAttentionPipeline::kMaxK>{}),
                                       sequence<kPadASeqLen, kPadAB0HeadSz>{});
            }();

            const auto b0_dram = [&]() {
                const auto b0_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    b0_ptr,
                    make_tuple(kargs.seqlen, kargs.head_sz),
                    make_tuple(kargs.b0_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentB0>{},
                    number<1>{});
                return pad_tensor_view(b0_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kN0>{},
                                                  number<MultiheadAttentionPipeline::kK0>{}),
                                       sequence<kPadSeqLen, kPadAB0HeadSz>{});
            }();

            const auto b1_dram = [&]() {
                const auto b1_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    b1_ptr,
                    make_tuple(kargs.seqlen, kargs.b1_head_sz),
                    make_tuple(kargs.b1_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentB1>{},
                    number<1>{});

                return pad_tensor_view(b1_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kK1>{},
                                                  number<MultiheadAttentionPipeline::kN1>{}),
                                       sequence<kPadSeqLen, kPadB1DHeadSz>{});
            }();

            const auto mask_dram = [&]() {
                const auto mask_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    mask_ptr,
                    make_tuple(kargs.seqlen),
                    make_tuple(1),
                    number<MultiheadAttentionPipeline::kAlignmentMask>{},
                    number<1>{});

                return pad_tensor_view(mask_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kN0>{}),
                                       sequence<kPadSeqLen>{});
            }();

            const auto qmask_dram = [&]() {
                const auto qmask_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    qmask_ptr,
                    make_tuple(kargs.a_seqlen),
                    make_tuple(1),
                    number<MultiheadAttentionPipeline::kAlignmentQMask>{},
                    number<1>{});

                return pad_tensor_view(qmask_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{}),
                                       sequence<kPadASeqLen>{});
            }();

            // pad the rows from 1 to kM, actual outputting will be only one row
            const auto d_dram = [&]() {
                const auto d_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    d_ptr,
                    make_tuple(kargs.a_seqlen, kargs.b1_head_sz),
                    make_tuple(kargs.d_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentD>{},
                    number<1>{});

                return pad_tensor_view(d_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                                  number<MultiheadAttentionPipeline::kN1>{}),
                                       sequence<kPadASeqLen, kPadB1DHeadSz>{});
            }();

            auto a_dram_window =
                make_tile_window(a_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                            number<MultiheadAttentionPipeline::kMaxK>{}),
                                 {i_seq, 0});

            auto b0_dram_window =
                make_tile_window(b0_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kN0>{},
                                            number<MultiheadAttentionPipeline::kK0>{}),
                                 {0, 0});

            auto b1_dram_window =
                make_tile_window(b1_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kK1>{},
                                            number<MultiheadAttentionPipeline::kN1>{}),
                                 {0, 0});
            auto mask_dram_window = make_tile_window(
                mask_dram, make_tuple(number<MultiheadAttentionPipeline::kN0>{}), {0});

            auto qmask_dram_window = make_tile_window(
                qmask_dram, make_tuple(number<MultiheadAttentionPipeline::kM>{}), {i_seq});

            auto d_dram_window =
                make_tile_window(d_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                            number<MultiheadAttentionPipeline::kN1>{}),
                                 {i_seq, 0});
            auto d_acc_tile = MultiheadAttentionPipeline{}(a_dram_window,
                                                           b0_dram_window,
                                                           mask_dram_window,
                                                           qmask_dram_window,
                                                           b1_dram_window,
                                                           kargs.seqlen,
                                                           kargs.head_sz,
                                                           smem_ptr);

            EpiloguePipeline{}(d_dram_window, d_acc_tile);
        }
        else
        {
            long_index_t block_offset_a = static_cast<long_index_t>(i_nhead) * kargs.a_nhead_stride;
            long_index_t block_offset_b0 =
                static_cast<long_index_t>(i_nhead) * kargs.b0_nhead_stride;
            long_index_t block_offset_b1 =
                static_cast<long_index_t>(i_nhead) * kargs.b1_nhead_stride;

            long_index_t block_offset_d = static_cast<long_index_t>(i_nhead) * kargs.d_nhead_stride;

            const InOutDataType* a_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.a_ptr) + block_offset_a;
            const InOutDataType* b0_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.b0_ptr) + block_offset_b0;
            const MaskDataType* mask_ptr  = reinterpret_cast<const MaskDataType*>(kargs.mask_ptr);
            const MaskDataType* qmask_ptr = reinterpret_cast<const MaskDataType*>(kargs.qmask_ptr);
            const InOutDataType* b1_ptr =
                reinterpret_cast<const InOutDataType*>(kargs.b1_ptr) + block_offset_b1;
            InOutDataType* d_ptr = reinterpret_cast<InOutDataType*>(kargs.d_ptr) + block_offset_d;

            // A0/B0/B1/D/Mask DRAM and DRAM window
            const auto a_dram = [&]() {
                const auto a_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    a_ptr,
                    make_tuple(kargs.num_index * kargs.a_seqlen, kargs.head_sz),
                    make_tuple(kargs.a_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentA>{},
                    number<1>{});

                return pad_tensor_view(a_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                                  number<MultiheadAttentionPipeline::kMaxK>{}),
                                       sequence<kPadASeqLen, kPadAB0HeadSz>{});
            }();

            const auto b0_dram = [&]() {
                const auto b0_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    b0_ptr,
                    make_tuple(kargs.seqlen, kargs.head_sz),
                    make_tuple(kargs.b0_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentB0>{},
                    number<1>{});
                return pad_tensor_view(b0_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kN0>{},
                                                  number<MultiheadAttentionPipeline::kK0>{}),
                                       sequence<kPadSeqLen, kPadAB0HeadSz>{});
            }();

            const auto b1_dram = [&]() {
                const auto b1_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    b1_ptr,
                    make_tuple(kargs.seqlen, kargs.b1_head_sz),
                    make_tuple(kargs.b1_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentB1>{},
                    number<1>{});

                return pad_tensor_view(b1_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kK1>{},
                                                  number<MultiheadAttentionPipeline::kN1>{}),
                                       sequence<kPadSeqLen, kPadB1DHeadSz>{});
            }();

            const auto mask_dram = [&]() {
                const auto mask_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    mask_ptr,
                    make_tuple(kargs.seqlen),
                    make_tuple(1),
                    number<MultiheadAttentionPipeline::kAlignmentMask>{},
                    number<1>{});

                return pad_tensor_view(mask_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kN0>{}),
                                       sequence<kPadSeqLen>{});
            }();

            const auto qmask_dram = [&]() {
                const auto qmask_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    qmask_ptr,
                    make_tuple(kargs.num_index * kargs.a_seqlen),
                    make_tuple(1),
                    number<MultiheadAttentionPipeline::kAlignmentQMask>{},
                    number<1>{});

                return pad_tensor_view(qmask_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{}),
                                       sequence<kPadASeqLen>{});
            }();

            // pad the rows from 1 to kM, actual outputting will be only one row
            const auto d_dram = [&]() {
                const auto d_dram_naive = make_naive_tensor_view<address_space_enum::global>(
                    d_ptr,
                    make_tuple(kargs.num_index * kargs.a_seqlen, kargs.b1_head_sz),
                    make_tuple(kargs.d_seq_stride, 1),
                    number<MultiheadAttentionPipeline::kAlignmentD>{},
                    number<1>{});

                return pad_tensor_view(d_dram_naive,
                                       make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                                  number<MultiheadAttentionPipeline::kN1>{}),
                                       sequence<kPadASeqLen, kPadB1DHeadSz>{});
            }();

            auto a_dram_window =
                make_tile_window(a_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                            number<MultiheadAttentionPipeline::kMaxK>{}),
                                 {i_batch, 0});

            auto b0_dram_window =
                make_tile_window(b0_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kN0>{},
                                            number<MultiheadAttentionPipeline::kK0>{}),
                                 {0, 0});

            auto b1_dram_window =
                make_tile_window(b1_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kK1>{},
                                            number<MultiheadAttentionPipeline::kN1>{}),
                                 {0, 0});
            auto mask_dram_window = make_tile_window(
                mask_dram, make_tuple(number<MultiheadAttentionPipeline::kN0>{}), {0});

            auto qmask_dram_window = make_tile_window(
                qmask_dram, make_tuple(number<MultiheadAttentionPipeline::kM>{}), {i_batch});

            auto d_dram_window =
                make_tile_window(d_dram,
                                 make_tuple(number<MultiheadAttentionPipeline::kM>{},
                                            number<MultiheadAttentionPipeline::kN1>{}),
                                 {i_batch, 0});
            auto d_acc_tile = MultiheadAttentionPipeline{}(a_dram_window,
                                                           b0_dram_window,
                                                           mask_dram_window,
                                                           qmask_dram_window,
                                                           b1_dram_window,
                                                           kargs.seqlen,
                                                           kargs.head_sz,
                                                           smem_ptr);

            EpiloguePipeline{}(d_dram_window, d_acc_tile);
        }
    }
};

} // namespace ck_tile

import re
import random
import subprocess
import os

BUILD = "/root/workspace/composable_kernel/build_internal"
EXE = os.path.join(BUILD, "bin/tile_example_multihead_attention")

def parse_line(line):

    match = re.match(r'q: \[(None|[\d]+), ([\d]+), ([\d]+)\], k: \[(None|[\d]+), ([\d]+), ([\d]+)\], v: \[(None|[\d]+), ([\d]+), ([\d]+)\]', line)
    if not match:
        raise ValueError("Invalid line format: {}".format(line))

    groups = match.groups()
    
    a_none,  a_seq,  a_last_dim = groups[0], int(groups[1]), int(groups[2])
    b0_none, b0_seq, b0_last_dim = groups[3], int(groups[4]), int(groups[5])
    b1_none, b1_seq, b1_last_dim = groups[6], int(groups[7]), int(groups[8])
    
    return {
        'a' : (a_seq, a_last_dim),
        'b0': (b0_seq, b0_last_dim),
        'b1': (b1_seq, b1_last_dim)
    }

def generate_data(parsed_lines):
    results = []
    for parsed in parsed_lines:
        #b0_seq = b1_seq, a_head_dim = b0_head_dim
        a_seq, a_last_dim = parsed['a']
        b0_seq, b0_last_dim = parsed['b0']
        b1_seq, b1_last_dim = parsed['b1']
        
        for num_head in [4, 8]:
            if a_last_dim % num_head == 0 and b0_last_dim % num_head == 0 and b1_last_dim % num_head == 0:
                a_head_dim = a_last_dim // num_head
                b0_head_dim = b0_last_dim // num_head
                b1_head_dim = b1_last_dim // num_head
                
                a_index = random.randint(80, 2500)
                b_batch = random.randint(1, a_index - 1)
                
                results.append({
                    'a_index': a_index,
                    'b_batch': b_batch,
                    'a_seq': a_seq,
                    'b_seq': b0_seq,
                    'num_head': num_head,
                    'ab_head_dim': a_head_dim,
                    'b1_head_dim': b1_head_dim
                })
    return results

def run_command(cmd):
    try:
        result = subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True, result.stdout.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return False, e.stderr.decode('utf-8')

def execute_commands(results):
    precisions = ["fp16"]#, "bf16"]
    data_directions = ["n"]
    mask_maxs = [-1, 1, 2]
    qmask_maxs = [-1, 1, 2]
    input_layout = [0, 1]
    count = 0
    for result in results:
        a_index = result['a_index']
        b_batch = result['b_batch']
        a_seq = result['a_seq']
        b_seq = result['b_seq']
        num_head = result['num_head']
        ab_head_dim = result['ab_head_dim']
        b1_head_dim = result['b1_head_dim']
        if b_batch > a_index and a_index != 1:
            continue
        for prec in precisions:
            for il in input_layout:
                for dd in data_directions:
                    for maskmax in mask_maxs:
                        for qmaskmax in qmask_maxs:
                    
                            cmdline = "{0} -v=1 -prec={1} -b={2} -nidx={3} -nhead={4} -hsize={5} -seq={6} -a_seq={7} -init={8} -b1_hsize={9} -seed=123 -perf=0 -maskmax={10} -qmaskmax={11} -input_layout={12}".format(
                                EXE, prec, b_batch, a_index, num_head, ab_head_dim, b_seq, a_seq, dd, b1_head_dim, maskmax, qmaskmax, il
                            )
                            success, output = run_command(cmdline)

                            if success:
                                print("Passed: {}".format( cmdline))
                            else:
                                print("Failed: {}\n{}".format(cmdline, output))

def main():
    with open('config.txt', 'r') as file:
        lines = file.readlines()
    
    parsed_lines = [parse_line(line.strip()) for line in lines]
    results = generate_data(parsed_lines)
    
    execute_commands(results)

if __name__ == "__main__":
    main()
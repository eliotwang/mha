// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2024, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <ck_tile/core.hpp>

#include "multihead_attention_tile_shape.hpp"

namespace ck_tile {

template <typename InOutDataType_,
          typename GemmAccDataType_,
          typename SMPLComputeDataType_,
          typename MaskDataType_,
          typename MultiheadAttentionTileShape_>
struct MultiheadAttentionProblem
{
    using InOutDataType   = remove_cvref_t<InOutDataType_>;
    using GemmAccDataType = remove_cvref_t<GemmAccDataType_>;

    // DataType used when computing Softmax
    using SMPLComputeDataType = remove_cvref_t<SMPLComputeDataType_>;
    using MaskDataType        = remove_cvref_t<MaskDataType_>;

    using MultiheadAttentionTileShape = remove_cvref_t<MultiheadAttentionTileShape_>;

    static constexpr index_t kBlockSize = MultiheadAttentionTileShape::NumWarps * get_warp_size();
};

} // namespace ck_tile

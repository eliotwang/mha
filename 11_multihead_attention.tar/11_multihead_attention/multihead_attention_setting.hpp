// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2023, Advanced Micro Devices, Inc. All rights reserved.

#pragma once

#include <ck_tile/core.hpp>

#include "multihead_attention_tile_shape.hpp"

// Type configuration
template <typename DataType>
struct MultiheadAttentionTypeConfig;

template <>
struct MultiheadAttentionTypeConfig<ck_tile::fp16_t>
{
    using GemmAccDataType   = float;
    using SMComputeDataType = float;
};

// Tile-lengths: M N0 K0 N1 K1 MaxK (MaxK % K0 == 0, MaxK % N1 == 0, N0 % K1 == 0)
// template <ck_tile::index_t kM, ck_tile::index_t MaxK, ck_tile::index_t MaxKN>
// struct MultiheadAttnBlockTile
// {};

template <ck_tile::index_t kM, ck_tile::index_t MaxK, ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile
{
    using type        = ck_tile::sequence<kM, kM, 64, MaxKN, kM, MaxK>;
    using gemm0_warps = ck_tile::sequence<kM / 16, 1, 1>;
    using gemm1_warps = ck_tile::sequence<kM / 16, 1, 1>;
};

// kM=16, 1. a_seq=b0_seq <= 64 ; 2. a_seq=1, b0_seq>1, could be very large
template <>
struct MultiheadAttnBlockTile<16, 16, 16>
{
    using type        = ck_tile::sequence<16, 16, 16, 16, 16, 16>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<16, 16, MaxKN>
{
    using type        = ck_tile::sequence<16, 16, 16, MaxKN, 16, 16>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 2, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<16, MaxK, 16>
{
    using type        = ck_tile::sequence<16, 16, 32, 16, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 1, 1>;
};

template <ck_tile::index_t MaxK, ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<16, MaxK, MaxKN>
{
    using type        = ck_tile::sequence<16, 16, 32, MaxKN, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 2, 1>;
};

// kM=32/48/64, a_seq=b0_seq
template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<32, 16, MaxKN>
{
    using type        = ck_tile::sequence<32, 32, 16, MaxKN, 32, 16>;
    using gemm0_warps = ck_tile::sequence<2, 1, 1>;
    using gemm1_warps = ck_tile::sequence<2, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<32, 32, MaxKN>
{
    using type        = ck_tile::sequence<32, 32, 32, MaxKN, 32, 32>;
    using gemm0_warps = ck_tile::sequence<2, 1, 1>;
    using gemm1_warps = ck_tile::sequence<2, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<48, 16, MaxKN>
{
    using type        = ck_tile::sequence<48, 48, 16, MaxKN, 48, 16>;
    using gemm0_warps = ck_tile::sequence<3, 1, 1>;
    using gemm1_warps = ck_tile::sequence<3, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<48, 32, MaxKN>
{
    using type        = ck_tile::sequence<48, 48, 32, MaxKN, 48, 32>;
    using gemm0_warps = ck_tile::sequence<3, 1, 1>;
    using gemm1_warps = ck_tile::sequence<3, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<64, 16, MaxKN>
{
    using type        = ck_tile::sequence<64, 64, 16, MaxKN, 64, 16>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<64, 32, MaxKN>
{
    using type        = ck_tile::sequence<64, 64, 32, MaxKN, 64, 32>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<128, 16, MaxKN>
{
    using type        = ck_tile::sequence<128, 64, 16, MaxKN, 64, 16>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<128, 32, MaxKN>
{
    using type        = ck_tile::sequence<128, 64, 32, MaxKN, 64, 32>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<128, 64, MaxKN>
{
    using type        = ck_tile::sequence<128, 64, 64, MaxKN, 64, 64>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<128, 128, MaxKN>
{
    using type        = ck_tile::sequence<128, 64, 64, MaxKN, 64, 128>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<128, 256, MaxKN>
{
    using type        = ck_tile::sequence<128, 64, 64, MaxKN, 64, 256>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<256, 16, MaxKN>
{
    using type        = ck_tile::sequence<256, 64, 16, MaxKN, 64, 16>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<256, 32, MaxKN>
{
    using type        = ck_tile::sequence<256, 64, 32, MaxKN, 64, 32>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<256, 64, MaxKN>
{
    using type        = ck_tile::sequence<256, 64, 64, MaxKN, 64, 64>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<256, 128, MaxKN>
{
    using type        = ck_tile::sequence<256, 64, 64, MaxKN, 64, 128>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxKN>
struct MultiheadAttnBlockTile<256, 256, MaxKN>
{
    using type        = ck_tile::sequence<256, 64, 64, MaxKN, 64, 256>;
    using gemm0_warps = ck_tile::sequence<4, 1, 1>;
    using gemm1_warps = ck_tile::sequence<4, 1, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<1, MaxK, 16>
{
    using type        = ck_tile::sequence<1, 64, 16, 64, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 1, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<1, MaxK, 32>
{
    using type        = ck_tile::sequence<1, 64, 16, 64, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 1, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<1, MaxK, 64>
{
    using type        = ck_tile::sequence<1, 64, 16, 64, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 1, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<1, MaxK, 128>
{
    using type        = ck_tile::sequence<1, 64, 16, 128, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 2, 1>;
};

template <ck_tile::index_t MaxK>
struct MultiheadAttnBlockTile<1, MaxK, 256>
{
    using type        = ck_tile::sequence<1, 64, 16, 256, 16, MaxK>;
    using gemm0_warps = ck_tile::sequence<1, 1, 1>;
    using gemm1_warps = ck_tile::sequence<1, 4, 1>;
};
// WarpTile is not used currently except being used for asserting the defined warp-gemm sizes
using MultiheadAttnWarpTile0 = ck_tile::sequence<16, 16, 16>;
using MultiheadAttnWarpTile1 = ck_tile::sequence<16, 16, 16>;

using MultiheadAttnWarpTile2 = ck_tile::sequence<1, 64, 16>;
using MultiheadAttnWarpTile3 = ck_tile::sequence<1, 64, 16>;

template <ck_tile::index_t kM, ck_tile::index_t MaxK, ck_tile::index_t MaxKN>
struct MultiheadAttentionTileShape
    : ck_tile::MultiheadAttentionTileSetting<
          typename MultiheadAttnBlockTile<kM, MaxK, MaxKN>::type,
          typename MultiheadAttnBlockTile<kM, MaxK, MaxKN>::gemm0_warps,
          MultiheadAttnWarpTile0,
          typename MultiheadAttnBlockTile<kM, MaxK, MaxKN>::gemm1_warps,
          MultiheadAttnWarpTile1>
{
};

template <ck_tile::index_t MaxK, ck_tile::index_t MaxKN>
struct MultiheadAttentionTileShape<1, MaxK, MaxKN>
    : ck_tile::MultiheadAttentionTileSetting<
          typename MultiheadAttnBlockTile<1, MaxK, MaxKN>::type,
          typename MultiheadAttnBlockTile<1, MaxK, MaxKN>::gemm0_warps,
          MultiheadAttnWarpTile2,
          typename MultiheadAttnBlockTile<1, MaxK, MaxKN>::gemm1_warps,
          MultiheadAttnWarpTile3>
{
};
